(function(){
$APP.icurate_bx.popup={};chrome.tabs.create({url:chrome.runtime.getURL("sidebar.html")});
}).call(this);