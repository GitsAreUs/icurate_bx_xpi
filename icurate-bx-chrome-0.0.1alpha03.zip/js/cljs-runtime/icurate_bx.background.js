goog.provide('icurate_bx.background');
icurate_bx.background.browser = icurate_bx.bookmark.get_browser_object.cljs$core$IFn$_invoke$arity$0();
icurate_bx.background.default_bm_folders = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 3, ["Mobile Bookmarks",null,"Bookmarks Menu",null,"Bookmarks Toolbar",null], null), null);
icurate_bx.background.get_param = (function icurate_bx$background$get_param(url){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"with-credentials?","with-credentials?",-1773202222),false,new cljs.core.Keyword(null,"query-params","query-params",900640534),new cljs.core.PersistentArrayMap(null, 1, ["query",["mutation{curate_url(url: \"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(url),"\")}"].join('')], null)], null);
});
icurate_bx.background.curate_bms = (function icurate_bx$background$curate_bms(b_node){
var temp__5735__auto___28386 = b_node.children;
if(cljs.core.truth_(temp__5735__auto___28386)){
var children_28387 = temp__5735__auto___28386;
if(cljs.core.truth_((function (){var G__28114 = b_node.title;
return (icurate_bx.background.default_bm_folders.cljs$core$IFn$_invoke$arity$1 ? icurate_bx.background.default_bm_folders.cljs$core$IFn$_invoke$arity$1(G__28114) : icurate_bx.background.default_bm_folders.call(null,G__28114));
})())){
} else {
console.log(["Curating :",cljs.core.str.cljs$core$IFn$_invoke$arity$1(b_node.type)," : ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(b_node.title)].join(''));

var seq__28115_28388 = cljs.core.seq(children_28387);
var chunk__28116_28389 = null;
var count__28117_28390 = (0);
var i__28118_28391 = (0);
while(true){
if((i__28118_28391 < count__28117_28390)){
var bm_28392 = chunk__28116_28389.cljs$core$IIndexed$_nth$arity$2(null,i__28118_28391);
(icurate_bx.background.curate_bms.cljs$core$IFn$_invoke$arity$1 ? icurate_bx.background.curate_bms.cljs$core$IFn$_invoke$arity$1(bm_28392) : icurate_bx.background.curate_bms.call(null,bm_28392));


var G__28393 = seq__28115_28388;
var G__28394 = chunk__28116_28389;
var G__28395 = count__28117_28390;
var G__28396 = (i__28118_28391 + (1));
seq__28115_28388 = G__28393;
chunk__28116_28389 = G__28394;
count__28117_28390 = G__28395;
i__28118_28391 = G__28396;
continue;
} else {
var temp__5735__auto___28397__$1 = cljs.core.seq(seq__28115_28388);
if(temp__5735__auto___28397__$1){
var seq__28115_28398__$1 = temp__5735__auto___28397__$1;
if(cljs.core.chunked_seq_QMARK_(seq__28115_28398__$1)){
var c__4556__auto___28399 = cljs.core.chunk_first(seq__28115_28398__$1);
var G__28400 = cljs.core.chunk_rest(seq__28115_28398__$1);
var G__28401 = c__4556__auto___28399;
var G__28402 = cljs.core.count(c__4556__auto___28399);
var G__28403 = (0);
seq__28115_28388 = G__28400;
chunk__28116_28389 = G__28401;
count__28117_28390 = G__28402;
i__28118_28391 = G__28403;
continue;
} else {
var bm_28404 = cljs.core.first(seq__28115_28398__$1);
(icurate_bx.background.curate_bms.cljs$core$IFn$_invoke$arity$1 ? icurate_bx.background.curate_bms.cljs$core$IFn$_invoke$arity$1(bm_28404) : icurate_bx.background.curate_bms.call(null,bm_28404));


var G__28405 = cljs.core.next(seq__28115_28398__$1);
var G__28406 = null;
var G__28407 = (0);
var G__28408 = (0);
seq__28115_28388 = G__28405;
chunk__28116_28389 = G__28406;
count__28117_28390 = G__28407;
i__28118_28391 = G__28408;
continue;
}
} else {
}
}
break;
}
}
} else {
}

var temp__5735__auto__ = b_node.url;
if(cljs.core.truth_(temp__5735__auto__)){
var url = temp__5735__auto__;
console.log(["bm title: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(b_node.title)].join(''));

console.log(["Curting bm url  : ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(url)].join(''));

return cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(icurate_bx.bookmark.gql_ep,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([icurate_bx.background.get_param(url)], 0));
} else {
return null;
}
});
icurate_bx.background.read_bm_urls = (function icurate_bx$background$read_bm_urls(){
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_28191){
var state_val_28192 = (state_28191[(1)]);
if((state_val_28192 === (7))){
var inst_28142 = (state_28191[(7)]);
var inst_28149 = (function(){throw inst_28142})();
var state_28191__$1 = state_28191;
var statearr_28193_28409 = state_28191__$1;
(statearr_28193_28409[(2)] = inst_28149);

(statearr_28193_28409[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (20))){
var inst_28182 = (state_28191[(2)]);
var state_28191__$1 = state_28191;
var statearr_28194_28410 = state_28191__$1;
(statearr_28194_28410[(2)] = inst_28182);

(statearr_28194_28410[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (1))){
var inst_28119 = (state_28191[(8)]);
var inst_28119__$1 = (icurate_bx.background.browser.bookmarks.getTree.cljs$core$IFn$_invoke$arity$0 ? icurate_bx.background.browser.bookmarks.getTree.cljs$core$IFn$_invoke$arity$0() : icurate_bx.background.browser.bookmarks.getTree.call(null));
var inst_28120 = cljs.core.async.interop.p__GT_c(inst_28119__$1);
var state_28191__$1 = (function (){var statearr_28195 = state_28191;
(statearr_28195[(8)] = inst_28119__$1);

return statearr_28195;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28191__$1,(2),inst_28120);
} else {
if((state_val_28192 === (4))){
var inst_28122 = (state_28191[(9)]);
var state_28191__$1 = state_28191;
var statearr_28196_28411 = state_28191__$1;
(statearr_28196_28411[(2)] = inst_28122);

(statearr_28196_28411[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (15))){
var inst_28168 = (state_28191[(10)]);
var inst_28170 = cljs.core.chunked_seq_QMARK_(inst_28168);
var state_28191__$1 = state_28191;
if(inst_28170){
var statearr_28197_28412 = state_28191__$1;
(statearr_28197_28412[(1)] = (18));

} else {
var statearr_28198_28413 = state_28191__$1;
(statearr_28198_28413[(1)] = (19));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (13))){
var inst_28155 = (state_28191[(11)]);
var inst_28168 = (state_28191[(10)]);
var inst_28168__$1 = cljs.core.seq(inst_28155);
var state_28191__$1 = (function (){var statearr_28199 = state_28191;
(statearr_28199[(10)] = inst_28168__$1);

return statearr_28199;
})();
if(inst_28168__$1){
var statearr_28200_28414 = state_28191__$1;
(statearr_28200_28414[(1)] = (15));

} else {
var statearr_28201_28415 = state_28191__$1;
(statearr_28201_28415[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (6))){
var inst_28142 = (state_28191[(7)]);
var inst_28142__$1 = (state_28191[(2)]);
var inst_28143 = (inst_28142__$1 instanceof cljs.core.ExceptionInfo);
var inst_28144 = cljs.core.ex_data(inst_28142__$1);
var inst_28145 = new cljs.core.Keyword(null,"error","error",-978969032).cljs$core$IFn$_invoke$arity$1(inst_28144);
var inst_28146 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_28145,new cljs.core.Keyword(null,"promise-error","promise-error",-90673560));
var inst_28147 = ((inst_28143) && (inst_28146));
var state_28191__$1 = (function (){var statearr_28202 = state_28191;
(statearr_28202[(7)] = inst_28142__$1);

return statearr_28202;
})();
if(cljs.core.truth_(inst_28147)){
var statearr_28203_28416 = state_28191__$1;
(statearr_28203_28416[(1)] = (7));

} else {
var statearr_28204_28417 = state_28191__$1;
(statearr_28204_28417[(1)] = (8));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (17))){
var inst_28185 = (state_28191[(2)]);
var state_28191__$1 = state_28191;
var statearr_28208_28418 = state_28191__$1;
(statearr_28208_28418[(2)] = inst_28185);

(statearr_28208_28418[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (3))){
var inst_28122 = (state_28191[(9)]);
var inst_28129 = (function(){throw inst_28122})();
var state_28191__$1 = state_28191;
var statearr_28209_28419 = state_28191__$1;
(statearr_28209_28419[(2)] = inst_28129);

(statearr_28209_28419[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (12))){
var inst_28157 = (state_28191[(12)]);
var inst_28155 = (state_28191[(11)]);
var inst_28158 = (state_28191[(13)]);
var inst_28156 = (state_28191[(14)]);
var inst_28163 = cljs.core._nth(inst_28156,inst_28158);
var inst_28164 = icurate_bx.background.curate_bms(inst_28163);
var inst_28165 = (inst_28158 + (1));
var tmp28205 = inst_28157;
var tmp28206 = inst_28155;
var tmp28207 = inst_28156;
var inst_28155__$1 = tmp28206;
var inst_28156__$1 = tmp28207;
var inst_28157__$1 = tmp28205;
var inst_28158__$1 = inst_28165;
var state_28191__$1 = (function (){var statearr_28210 = state_28191;
(statearr_28210[(12)] = inst_28157__$1);

(statearr_28210[(11)] = inst_28155__$1);

(statearr_28210[(13)] = inst_28158__$1);

(statearr_28210[(14)] = inst_28156__$1);

(statearr_28210[(15)] = inst_28164);

return statearr_28210;
})();
var statearr_28211_28420 = state_28191__$1;
(statearr_28211_28420[(2)] = null);

(statearr_28211_28420[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (2))){
var inst_28122 = (state_28191[(9)]);
var inst_28122__$1 = (state_28191[(2)]);
var inst_28123 = (inst_28122__$1 instanceof cljs.core.ExceptionInfo);
var inst_28124 = cljs.core.ex_data(inst_28122__$1);
var inst_28125 = new cljs.core.Keyword(null,"error","error",-978969032).cljs$core$IFn$_invoke$arity$1(inst_28124);
var inst_28126 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_28125,new cljs.core.Keyword(null,"promise-error","promise-error",-90673560));
var inst_28127 = ((inst_28123) && (inst_28126));
var state_28191__$1 = (function (){var statearr_28212 = state_28191;
(statearr_28212[(9)] = inst_28122__$1);

return statearr_28212;
})();
if(cljs.core.truth_(inst_28127)){
var statearr_28213_28421 = state_28191__$1;
(statearr_28213_28421[(1)] = (3));

} else {
var statearr_28214_28422 = state_28191__$1;
(statearr_28214_28422[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (19))){
var inst_28168 = (state_28191[(10)]);
var inst_28177 = cljs.core.first(inst_28168);
var inst_28178 = icurate_bx.background.curate_bms(inst_28177);
var inst_28179 = cljs.core.next(inst_28168);
var inst_28155 = inst_28179;
var inst_28156 = null;
var inst_28157 = (0);
var inst_28158 = (0);
var state_28191__$1 = (function (){var statearr_28215 = state_28191;
(statearr_28215[(16)] = inst_28178);

(statearr_28215[(12)] = inst_28157);

(statearr_28215[(11)] = inst_28155);

(statearr_28215[(13)] = inst_28158);

(statearr_28215[(14)] = inst_28156);

return statearr_28215;
})();
var statearr_28216_28423 = state_28191__$1;
(statearr_28216_28423[(2)] = null);

(statearr_28216_28423[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (11))){
var inst_28189 = (state_28191[(2)]);
var state_28191__$1 = state_28191;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28191__$1,inst_28189);
} else {
if((state_val_28192 === (9))){
var inst_28152 = (state_28191[(2)]);
var inst_28153 = cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(inst_28152);
var inst_28154 = cljs.core.seq(inst_28153);
var inst_28155 = inst_28154;
var inst_28156 = null;
var inst_28157 = (0);
var inst_28158 = (0);
var state_28191__$1 = (function (){var statearr_28217 = state_28191;
(statearr_28217[(12)] = inst_28157);

(statearr_28217[(11)] = inst_28155);

(statearr_28217[(13)] = inst_28158);

(statearr_28217[(14)] = inst_28156);

return statearr_28217;
})();
var statearr_28218_28424 = state_28191__$1;
(statearr_28218_28424[(2)] = null);

(statearr_28218_28424[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (5))){
var inst_28119 = (state_28191[(8)]);
var inst_28132 = (state_28191[(2)]);
var inst_28133 = cljs.core.count(inst_28132);
var inst_28134 = ["Bookmark nos: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_28133)].join('');
var inst_28135 = console.log(inst_28134);
var inst_28140 = cljs.core.async.interop.p__GT_c(inst_28119);
var state_28191__$1 = (function (){var statearr_28219 = state_28191;
(statearr_28219[(17)] = inst_28135);

return statearr_28219;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28191__$1,(6),inst_28140);
} else {
if((state_val_28192 === (14))){
var inst_28187 = (state_28191[(2)]);
var state_28191__$1 = state_28191;
var statearr_28220_28425 = state_28191__$1;
(statearr_28220_28425[(2)] = inst_28187);

(statearr_28220_28425[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (16))){
var state_28191__$1 = state_28191;
var statearr_28221_28426 = state_28191__$1;
(statearr_28221_28426[(2)] = null);

(statearr_28221_28426[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (10))){
var inst_28157 = (state_28191[(12)]);
var inst_28158 = (state_28191[(13)]);
var inst_28160 = (inst_28158 < inst_28157);
var inst_28161 = inst_28160;
var state_28191__$1 = state_28191;
if(cljs.core.truth_(inst_28161)){
var statearr_28222_28427 = state_28191__$1;
(statearr_28222_28427[(1)] = (12));

} else {
var statearr_28223_28428 = state_28191__$1;
(statearr_28223_28428[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (18))){
var inst_28168 = (state_28191[(10)]);
var inst_28172 = cljs.core.chunk_first(inst_28168);
var inst_28173 = cljs.core.chunk_rest(inst_28168);
var inst_28174 = cljs.core.count(inst_28172);
var inst_28155 = inst_28173;
var inst_28156 = inst_28172;
var inst_28157 = inst_28174;
var inst_28158 = (0);
var state_28191__$1 = (function (){var statearr_28224 = state_28191;
(statearr_28224[(12)] = inst_28157);

(statearr_28224[(11)] = inst_28155);

(statearr_28224[(13)] = inst_28158);

(statearr_28224[(14)] = inst_28156);

return statearr_28224;
})();
var statearr_28225_28429 = state_28191__$1;
(statearr_28225_28429[(2)] = null);

(statearr_28225_28429[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28192 === (8))){
var inst_28142 = (state_28191[(7)]);
var state_28191__$1 = state_28191;
var statearr_28226_28430 = state_28191__$1;
(statearr_28226_28430[(2)] = inst_28142);

(statearr_28226_28430[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var icurate_bx$background$read_bm_urls_$_state_machine__26357__auto__ = null;
var icurate_bx$background$read_bm_urls_$_state_machine__26357__auto____0 = (function (){
var statearr_28227 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_28227[(0)] = icurate_bx$background$read_bm_urls_$_state_machine__26357__auto__);

(statearr_28227[(1)] = (1));

return statearr_28227;
});
var icurate_bx$background$read_bm_urls_$_state_machine__26357__auto____1 = (function (state_28191){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_28191);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e28228){var ex__26360__auto__ = e28228;
var statearr_28229_28431 = state_28191;
(statearr_28229_28431[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_28191[(4)]))){
var statearr_28230_28432 = state_28191;
(statearr_28230_28432[(1)] = cljs.core.first((state_28191[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__28433 = state_28191;
state_28191 = G__28433;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$background$read_bm_urls_$_state_machine__26357__auto__ = function(state_28191){
switch(arguments.length){
case 0:
return icurate_bx$background$read_bm_urls_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$background$read_bm_urls_$_state_machine__26357__auto____1.call(this,state_28191);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$background$read_bm_urls_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$background$read_bm_urls_$_state_machine__26357__auto____0;
icurate_bx$background$read_bm_urls_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$background$read_bm_urls_$_state_machine__26357__auto____1;
return icurate_bx$background$read_bm_urls_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_28231 = f__26536__auto__();
(statearr_28231[(6)] = c__26535__auto__);

return statearr_28231;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
icurate_bx.background.add_bookmark_listener = (function icurate_bx$background$add_bookmark_listener(id,bm_node){
console.log(id);

console.log("Bookmarked : ",bm_node.url);

return icurate_bx.indexeddb.add_bookmark(bm_node);
});
icurate_bx.background.browser.bookmarks.onCreated.addListener(icurate_bx.background.add_bookmark_listener);
browser.contextMenus.remove("icurate_screen_shot");
browser.contextMenus.remove("icurate_selected_text");
icurate_bx.background.on_context_menu_created = (function icurate_bx$background$on_context_menu_created(){
if(cljs.core.truth_(icurate_bx.background.browser.runtime.lastError)){
return console.log("Error",icurate_bx.background.browser.runtime.lastError);
} else {
return console.log("ContextMenu added.");
}
});
icurate_bx.background.icurate_screen_shot = ({"id": "icurate_screen_shot", "title": "icurate Screenshot", "contexts": ["page"]});
icurate_bx.background.icurate_text_selection = ({"id": "icurate_selected_text", "title": "icurate Selected Text", "contexts": ["page","selection"]});
(icurate_bx.background.browser.contextMenus.create.cljs$core$IFn$_invoke$arity$2 ? icurate_bx.background.browser.contextMenus.create.cljs$core$IFn$_invoke$arity$2(icurate_bx.background.icurate_screen_shot,icurate_bx.background.on_context_menu_created) : icurate_bx.background.browser.contextMenus.create.call(null,icurate_bx.background.icurate_screen_shot,icurate_bx.background.on_context_menu_created));
(icurate_bx.background.browser.contextMenus.create.cljs$core$IFn$_invoke$arity$2 ? icurate_bx.background.browser.contextMenus.create.cljs$core$IFn$_invoke$arity$2(icurate_bx.background.icurate_text_selection,icurate_bx.background.on_context_menu_created) : icurate_bx.background.browser.contextMenus.create.call(null,icurate_bx.background.icurate_text_selection,icurate_bx.background.on_context_menu_created));
icurate_bx.background.post_xhr = (function icurate_bx$background$post_xhr(gql_str){
var xhr = (new XMLHttpRequest());
var param = JSON.stringify(cljs.core.clj__GT_js(cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"query","query",-1288509510)],[gql_str])));
xhr.open("POST",icurate_bx.bookmark.gql_ep,true);

xhr.setRequestHeader("Content-Type","application/json");

(xhr.withCredentials = true);

(xhr.responseType = "json");

(xhr.onreadystatechange = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(xhr.readystate,(4)))?console.log(xhr.responseText):null));

xhr.send(param);

return console.log("Posted text selection: ",param);
});
icurate_bx.background.upload_xhr = (function icurate_bx$background$upload_xhr(file,url,title){
var xhr = (new XMLHttpRequest());
var form_data = (new FormData());
form_data.append("file",file);

form_data.append("url",url);

form_data.append("title",title);

xhr.open("POST",[icurate_bx.bookmark.gql_ep,"/upload"].join(''));

(xhr.withCredentials = true);

(xhr.responseType = "json");

xhr.send(form_data);

return console.log("Uploading page shot....");
});
browser.contextMenus.onClicked.addListener((function (info,tab){
console.log("Content Menu Clicked: ",info.menuItemId);

var pred__28232 = cljs.core._EQ_;
var expr__28233 = info.menuItemId;
if(cljs.core.truth_((pred__28232.cljs$core$IFn$_invoke$arity$2 ? pred__28232.cljs$core$IFn$_invoke$arity$2("icurate_screen_shot",expr__28233) : pred__28232.call(null,"icurate_screen_shot",expr__28233)))){
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_28301){
var state_val_28302 = (state_28301[(1)]);
if((state_val_28302 === (7))){
var state_28301__$1 = state_28301;
var statearr_28303_28434 = state_28301__$1;
(statearr_28303_28434[(2)] = null);

(statearr_28303_28434[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (1))){
var inst_28235 = navigator.clipboard.read();
var inst_28236 = cljs.core.async.interop.p__GT_c(inst_28235);
var state_28301__$1 = state_28301;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28301__$1,(2),inst_28236);
} else {
if((state_val_28302 === (4))){
var inst_28238 = (state_28301[(7)]);
var state_28301__$1 = state_28301;
var statearr_28304_28435 = state_28301__$1;
(statearr_28304_28435[(2)] = inst_28238);

(statearr_28304_28435[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (15))){
var state_28301__$1 = state_28301;
var statearr_28305_28436 = state_28301__$1;
(statearr_28305_28436[(2)] = null);

(statearr_28305_28436[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (13))){
var inst_28294 = (state_28301[(2)]);
var state_28301__$1 = state_28301;
var statearr_28306_28437 = state_28301__$1;
(statearr_28306_28437[(2)] = inst_28294);

(statearr_28306_28437[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (6))){
var inst_28251 = (state_28301[(8)]);
var inst_28255 = console.log("Page screen-shot taken.");
var inst_28260 = cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(inst_28251);
var inst_28261 = cljs.core.seq(inst_28260);
var inst_28262 = inst_28261;
var inst_28263 = null;
var inst_28264 = (0);
var inst_28265 = (0);
var state_28301__$1 = (function (){var statearr_28307 = state_28301;
(statearr_28307[(9)] = inst_28265);

(statearr_28307[(10)] = inst_28262);

(statearr_28307[(11)] = inst_28263);

(statearr_28307[(12)] = inst_28255);

(statearr_28307[(13)] = inst_28264);

return statearr_28307;
})();
var statearr_28308_28438 = state_28301__$1;
(statearr_28308_28438[(2)] = null);

(statearr_28308_28438[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (17))){
var inst_28275 = (state_28301[(14)]);
var inst_28279 = cljs.core.chunk_first(inst_28275);
var inst_28280 = cljs.core.chunk_rest(inst_28275);
var inst_28281 = cljs.core.count(inst_28279);
var inst_28262 = inst_28280;
var inst_28263 = inst_28279;
var inst_28264 = inst_28281;
var inst_28265 = (0);
var state_28301__$1 = (function (){var statearr_28309 = state_28301;
(statearr_28309[(9)] = inst_28265);

(statearr_28309[(10)] = inst_28262);

(statearr_28309[(11)] = inst_28263);

(statearr_28309[(13)] = inst_28264);

return statearr_28309;
})();
var statearr_28310_28439 = state_28301__$1;
(statearr_28310_28439[(2)] = null);

(statearr_28310_28439[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (3))){
var inst_28238 = (state_28301[(7)]);
var inst_28245 = (function(){throw inst_28238})();
var state_28301__$1 = state_28301;
var statearr_28311_28440 = state_28301__$1;
(statearr_28311_28440[(2)] = inst_28245);

(statearr_28311_28440[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (12))){
var inst_28275 = (state_28301[(14)]);
var inst_28262 = (state_28301[(10)]);
var inst_28275__$1 = cljs.core.seq(inst_28262);
var state_28301__$1 = (function (){var statearr_28312 = state_28301;
(statearr_28312[(14)] = inst_28275__$1);

return statearr_28312;
})();
if(inst_28275__$1){
var statearr_28313_28441 = state_28301__$1;
(statearr_28313_28441[(1)] = (14));

} else {
var statearr_28314_28442 = state_28301__$1;
(statearr_28314_28442[(1)] = (15));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (2))){
var inst_28238 = (state_28301[(7)]);
var inst_28238__$1 = (state_28301[(2)]);
var inst_28239 = (inst_28238__$1 instanceof cljs.core.ExceptionInfo);
var inst_28240 = cljs.core.ex_data(inst_28238__$1);
var inst_28241 = new cljs.core.Keyword(null,"error","error",-978969032).cljs$core$IFn$_invoke$arity$1(inst_28240);
var inst_28242 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_28241,new cljs.core.Keyword(null,"promise-error","promise-error",-90673560));
var inst_28243 = ((inst_28239) && (inst_28242));
var state_28301__$1 = (function (){var statearr_28318 = state_28301;
(statearr_28318[(7)] = inst_28238__$1);

return statearr_28318;
})();
if(cljs.core.truth_(inst_28243)){
var statearr_28319_28443 = state_28301__$1;
(statearr_28319_28443[(1)] = (3));

} else {
var statearr_28320_28444 = state_28301__$1;
(statearr_28320_28444[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (19))){
var inst_28289 = (state_28301[(2)]);
var state_28301__$1 = state_28301;
var statearr_28321_28445 = state_28301__$1;
(statearr_28321_28445[(2)] = inst_28289);

(statearr_28321_28445[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (11))){
var inst_28250 = (state_28301[(15)]);
var inst_28265 = (state_28301[(9)]);
var inst_28249 = (state_28301[(16)]);
var inst_28262 = (state_28301[(10)]);
var inst_28263 = (state_28301[(11)]);
var inst_28264 = (state_28301[(13)]);
var inst_28270 = cljs.core._nth(inst_28263,inst_28265);
var inst_28271 = icurate_bx.background.upload_xhr(inst_28270,inst_28249,inst_28250);
var inst_28272 = (inst_28265 + (1));
var tmp28315 = inst_28262;
var tmp28316 = inst_28263;
var tmp28317 = inst_28264;
var inst_28262__$1 = tmp28315;
var inst_28263__$1 = tmp28316;
var inst_28264__$1 = tmp28317;
var inst_28265__$1 = inst_28272;
var state_28301__$1 = (function (){var statearr_28322 = state_28301;
(statearr_28322[(9)] = inst_28265__$1);

(statearr_28322[(17)] = inst_28271);

(statearr_28322[(10)] = inst_28262__$1);

(statearr_28322[(11)] = inst_28263__$1);

(statearr_28322[(13)] = inst_28264__$1);

return statearr_28322;
})();
var statearr_28323_28446 = state_28301__$1;
(statearr_28323_28446[(2)] = null);

(statearr_28323_28446[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (9))){
var inst_28265 = (state_28301[(9)]);
var inst_28264 = (state_28301[(13)]);
var inst_28267 = (inst_28265 < inst_28264);
var inst_28268 = inst_28267;
var state_28301__$1 = state_28301;
if(cljs.core.truth_(inst_28268)){
var statearr_28324_28447 = state_28301__$1;
(statearr_28324_28447[(1)] = (11));

} else {
var statearr_28325_28448 = state_28301__$1;
(statearr_28325_28448[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (5))){
var inst_28251 = (state_28301[(8)]);
var inst_28248 = (state_28301[(2)]);
var inst_28249 = tab.url;
var inst_28250 = tab.title;
var inst_28251__$1 = inst_28248.files;
var inst_28252 = inst_28251__$1.length;
var inst_28253 = ((0) < inst_28252);
var state_28301__$1 = (function (){var statearr_28326 = state_28301;
(statearr_28326[(15)] = inst_28250);

(statearr_28326[(16)] = inst_28249);

(statearr_28326[(8)] = inst_28251__$1);

return statearr_28326;
})();
if(cljs.core.truth_(inst_28253)){
var statearr_28327_28449 = state_28301__$1;
(statearr_28327_28449[(1)] = (6));

} else {
var statearr_28328_28450 = state_28301__$1;
(statearr_28328_28450[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (14))){
var inst_28275 = (state_28301[(14)]);
var inst_28277 = cljs.core.chunked_seq_QMARK_(inst_28275);
var state_28301__$1 = state_28301;
if(inst_28277){
var statearr_28329_28451 = state_28301__$1;
(statearr_28329_28451[(1)] = (17));

} else {
var statearr_28330_28452 = state_28301__$1;
(statearr_28330_28452[(1)] = (18));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (16))){
var inst_28292 = (state_28301[(2)]);
var state_28301__$1 = state_28301;
var statearr_28331_28453 = state_28301__$1;
(statearr_28331_28453[(2)] = inst_28292);

(statearr_28331_28453[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (10))){
var inst_28296 = (state_28301[(2)]);
var state_28301__$1 = state_28301;
var statearr_28332_28454 = state_28301__$1;
(statearr_28332_28454[(2)] = inst_28296);

(statearr_28332_28454[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (18))){
var inst_28250 = (state_28301[(15)]);
var inst_28275 = (state_28301[(14)]);
var inst_28249 = (state_28301[(16)]);
var inst_28284 = cljs.core.first(inst_28275);
var inst_28285 = icurate_bx.background.upload_xhr(inst_28284,inst_28249,inst_28250);
var inst_28286 = cljs.core.next(inst_28275);
var inst_28262 = inst_28286;
var inst_28263 = null;
var inst_28264 = (0);
var inst_28265 = (0);
var state_28301__$1 = (function (){var statearr_28333 = state_28301;
(statearr_28333[(18)] = inst_28285);

(statearr_28333[(9)] = inst_28265);

(statearr_28333[(10)] = inst_28262);

(statearr_28333[(11)] = inst_28263);

(statearr_28333[(13)] = inst_28264);

return statearr_28333;
})();
var statearr_28334_28455 = state_28301__$1;
(statearr_28334_28455[(2)] = null);

(statearr_28334_28455[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28302 === (8))){
var inst_28299 = (state_28301[(2)]);
var state_28301__$1 = state_28301;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28301__$1,inst_28299);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var icurate_bx$background$state_machine__26357__auto__ = null;
var icurate_bx$background$state_machine__26357__auto____0 = (function (){
var statearr_28335 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_28335[(0)] = icurate_bx$background$state_machine__26357__auto__);

(statearr_28335[(1)] = (1));

return statearr_28335;
});
var icurate_bx$background$state_machine__26357__auto____1 = (function (state_28301){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_28301);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e28336){var ex__26360__auto__ = e28336;
var statearr_28337_28456 = state_28301;
(statearr_28337_28456[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_28301[(4)]))){
var statearr_28338_28457 = state_28301;
(statearr_28338_28457[(1)] = cljs.core.first((state_28301[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__28458 = state_28301;
state_28301 = G__28458;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$background$state_machine__26357__auto__ = function(state_28301){
switch(arguments.length){
case 0:
return icurate_bx$background$state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$background$state_machine__26357__auto____1.call(this,state_28301);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$background$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$background$state_machine__26357__auto____0;
icurate_bx$background$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$background$state_machine__26357__auto____1;
return icurate_bx$background$state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_28339 = f__26536__auto__();
(statearr_28339[(6)] = c__26535__auto__);

return statearr_28339;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
} else {
if(cljs.core.truth_((pred__28232.cljs$core$IFn$_invoke$arity$2 ? pred__28232.cljs$core$IFn$_invoke$arity$2("icurate_selected_text",expr__28233) : pred__28232.call(null,"icurate_selected_text",expr__28233)))){
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_28367){
var state_val_28368 = (state_28367[(1)]);
if((state_val_28368 === (1))){
var inst_28340 = navigator.clipboard.readText();
var inst_28341 = cljs.core.async.interop.p__GT_c(inst_28340);
var state_28367__$1 = state_28367;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28367__$1,(2),inst_28341);
} else {
if((state_val_28368 === (2))){
var inst_28343 = (state_28367[(7)]);
var inst_28343__$1 = (state_28367[(2)]);
var inst_28344 = (inst_28343__$1 instanceof cljs.core.ExceptionInfo);
var inst_28345 = cljs.core.ex_data(inst_28343__$1);
var inst_28346 = new cljs.core.Keyword(null,"error","error",-978969032).cljs$core$IFn$_invoke$arity$1(inst_28345);
var inst_28347 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_28346,new cljs.core.Keyword(null,"promise-error","promise-error",-90673560));
var inst_28348 = ((inst_28344) && (inst_28347));
var state_28367__$1 = (function (){var statearr_28369 = state_28367;
(statearr_28369[(7)] = inst_28343__$1);

return statearr_28369;
})();
if(cljs.core.truth_(inst_28348)){
var statearr_28370_28459 = state_28367__$1;
(statearr_28370_28459[(1)] = (3));

} else {
var statearr_28371_28460 = state_28367__$1;
(statearr_28371_28460[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28368 === (3))){
var inst_28343 = (state_28367[(7)]);
var inst_28350 = (function(){throw inst_28343})();
var state_28367__$1 = state_28367;
var statearr_28372_28461 = state_28367__$1;
(statearr_28372_28461[(2)] = inst_28350);

(statearr_28372_28461[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28368 === (4))){
var inst_28343 = (state_28367[(7)]);
var state_28367__$1 = state_28367;
var statearr_28373_28462 = state_28367__$1;
(statearr_28373_28462[(2)] = inst_28343);

(statearr_28373_28462[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28368 === (5))){
var inst_28353 = (state_28367[(2)]);
var inst_28354 = cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_28353], 0));
var inst_28355 = cljs.core.empty_QMARK_(inst_28353);
var state_28367__$1 = (function (){var statearr_28374 = state_28367;
(statearr_28374[(8)] = inst_28354);

return statearr_28374;
})();
if(inst_28355){
var statearr_28375_28463 = state_28367__$1;
(statearr_28375_28463[(1)] = (6));

} else {
var statearr_28376_28464 = state_28367__$1;
(statearr_28376_28464[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28368 === (6))){
var state_28367__$1 = state_28367;
var statearr_28377_28465 = state_28367__$1;
(statearr_28377_28465[(2)] = null);

(statearr_28377_28465[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28368 === (7))){
var inst_28354 = (state_28367[(8)]);
var inst_28358 = tab.url;
var inst_28359 = cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_28358], 0));
var inst_28360 = tab.title;
var inst_28361 = cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_28360], 0));
var inst_28362 = ["mutation{curate_content(url: ",inst_28359,", title: ",inst_28361,", summary: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_28354),", content: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_28354),")}"].join('');
var inst_28363 = icurate_bx.background.post_xhr(inst_28362);
var state_28367__$1 = state_28367;
var statearr_28378_28466 = state_28367__$1;
(statearr_28378_28466[(2)] = inst_28363);

(statearr_28378_28466[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_28368 === (8))){
var inst_28365 = (state_28367[(2)]);
var state_28367__$1 = state_28367;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28367__$1,inst_28365);
} else {
return null;
}
}
}
}
}
}
}
}
});
return (function() {
var icurate_bx$background$state_machine__26357__auto__ = null;
var icurate_bx$background$state_machine__26357__auto____0 = (function (){
var statearr_28379 = [null,null,null,null,null,null,null,null,null];
(statearr_28379[(0)] = icurate_bx$background$state_machine__26357__auto__);

(statearr_28379[(1)] = (1));

return statearr_28379;
});
var icurate_bx$background$state_machine__26357__auto____1 = (function (state_28367){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_28367);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e28380){var ex__26360__auto__ = e28380;
var statearr_28381_28467 = state_28367;
(statearr_28381_28467[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_28367[(4)]))){
var statearr_28382_28468 = state_28367;
(statearr_28382_28468[(1)] = cljs.core.first((state_28367[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__28469 = state_28367;
state_28367 = G__28469;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$background$state_machine__26357__auto__ = function(state_28367){
switch(arguments.length){
case 0:
return icurate_bx$background$state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$background$state_machine__26357__auto____1.call(this,state_28367);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$background$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$background$state_machine__26357__auto____0;
icurate_bx$background$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$background$state_machine__26357__auto____1;
return icurate_bx$background$state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_28383 = f__26536__auto__();
(statearr_28383[(6)] = c__26535__auto__);

return statearr_28383;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
} else {
return console.log(info.menuItemId," Not an icurate Menu.");
}
}
}));
icurate_bx.background.browser.runtime.onMessage.addListener((function (message,sender,callback){
var m_28470 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$variadic(message,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true], 0));
var map__28384_28471 = m_28470;
var map__28384_28472__$1 = (((((!((map__28384_28471 == null))))?(((((map__28384_28471.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__28384_28471.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__28384_28471):map__28384_28471);
var to_28473 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__28384_28472__$1,new cljs.core.Keyword(null,"to","to",192099007));
var cmd_28474 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__28384_28472__$1,new cljs.core.Keyword(null,"cmd","cmd",-302931143));
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [to_28473,cmd_28474], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["background","start-curator"], null))){
icurate_bx.indexeddb.start_curator();
} else {
}

if(cljs.core.truth_(callback)){
return (callback.cljs$core$IFn$_invoke$arity$0 ? callback.cljs$core$IFn$_invoke$arity$0() : callback.call(null));
} else {
return null;
}
}));
icurate_bx.indexeddb.initDB();
module$icurate_bx$omnibox.registerOmnibox();

//# sourceMappingURL=icurate_bx.background.js.map
