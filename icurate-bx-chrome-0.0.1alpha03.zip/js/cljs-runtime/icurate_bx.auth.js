goog.provide('icurate_bx.auth');
icurate_bx.auth.cookie_options = (function (){var options = (new goog.net.Cookies.SetOptions());
(options.domain = icurate_bx.bookmark.gql_ep);

(options.maxAge = (-1));

(options.path = "/");

(options.sameSite = "Strict");

(options.secure = true);

return options;
})();
icurate_bx.auth.auth_session = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword("icurate-bx.auth","authenticated?","icurate-bx.auth/authenticated?",-1180388341),false], null));
icurate_bx.auth.authenticated_QMARK_ = (function icurate_bx$auth$authenticated_QMARK_(){
return new cljs.core.Keyword("icurate-bx.auth","authenticated?","icurate-bx.auth/authenticated?",-1180388341).cljs$core$IFn$_invoke$arity$1(cljs.core.deref(icurate_bx.auth.auth_session));
});
icurate_bx.auth.get_identity = (function icurate_bx$auth$get_identity(){
var identity = goog.net.cookies.get("G_ENABLED_IDPS");
console.debug("Identity Cookie :",identity);

return identity;
});
icurate_bx.auth.latest_bookmarks = (function icurate_bx$auth$latest_bookmarks(var_args){
var G__26780 = arguments.length;
switch (G__26780) {
case 0:
return icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$0();

break;
case 2:
return icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$0 = (function (){
var params = new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"with-credentials?","with-credentials?",-1773202222),true,new cljs.core.Keyword(null,"query-params","query-params",900640534),new cljs.core.PersistentArrayMap(null, 1, ["query","{match_url(search: \"\"){id url title summary}}"], null)], null);
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_26797){
var state_val_26798 = (state_26797[(1)]);
if((state_val_26798 === (1))){
var inst_26785 = cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(icurate_bx.bookmark.gql_ep,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([params], 0));
var state_26797__$1 = state_26797;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_26797__$1,(2),inst_26785);
} else {
if((state_val_26798 === (2))){
var inst_26787 = (state_26797[(2)]);
var inst_26788 = new cljs.core.Keyword(null,"status","status",-1997798413).cljs$core$IFn$_invoke$arity$1(inst_26787);
var inst_26789 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26790 = [new cljs.core.Keyword(null,"body","body",-2049205669),new cljs.core.Keyword(null,"data","data",-232669377),new cljs.core.Keyword(null,"match_url","match_url",-1844276896)];
var inst_26791 = (new cljs.core.PersistentVector(null,3,(5),inst_26789,inst_26790,null));
var inst_26792 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(inst_26787,inst_26791);
var inst_26793 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26794 = [inst_26788,inst_26792];
var inst_26795 = (new cljs.core.PersistentVector(null,2,(5),inst_26793,inst_26794,null));
var state_26797__$1 = state_26797;
return cljs.core.async.impl.ioc_helpers.return_chan(state_26797__$1,inst_26795);
} else {
return null;
}
}
});
return (function() {
var icurate_bx$auth$state_machine__26357__auto__ = null;
var icurate_bx$auth$state_machine__26357__auto____0 = (function (){
var statearr_26809 = [null,null,null,null,null,null,null];
(statearr_26809[(0)] = icurate_bx$auth$state_machine__26357__auto__);

(statearr_26809[(1)] = (1));

return statearr_26809;
});
var icurate_bx$auth$state_machine__26357__auto____1 = (function (state_26797){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_26797);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e26813){var ex__26360__auto__ = e26813;
var statearr_26814_27058 = state_26797;
(statearr_26814_27058[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_26797[(4)]))){
var statearr_26815_27059 = state_26797;
(statearr_26815_27059[(1)] = cljs.core.first((state_26797[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27060 = state_26797;
state_26797 = G__27060;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$auth$state_machine__26357__auto__ = function(state_26797){
switch(arguments.length){
case 0:
return icurate_bx$auth$state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$auth$state_machine__26357__auto____1.call(this,state_26797);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$auth$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$auth$state_machine__26357__auto____0;
icurate_bx$auth$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$auth$state_machine__26357__auto____1;
return icurate_bx$auth$state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_26819 = f__26536__auto__();
(statearr_26819[(6)] = c__26535__auto__);

return statearr_26819;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
}));

(icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$2 = (function (google_id_token,req_user_info){
var params = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"with-credentials?","with-credentials?",-1773202222),true,new cljs.core.Keyword(null,"headers","headers",-835030129),new cljs.core.PersistentArrayMap(null, 1, ["Authorization",["Token ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(google_id_token)].join('')], null),new cljs.core.Keyword(null,"query-params","query-params",900640534),new cljs.core.PersistentArrayMap(null, 2, ["query","{match_url(search: \"\"){id url title summary}}","user-info",cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([req_user_info], 0))], null)], null);
return cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(icurate_bx.bookmark.gql_ep,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([params], 0));
}));

(icurate_bx.auth.latest_bookmarks.cljs$lang$maxFixedArity = 2);

icurate_bx.auth.validate_google_token = (function icurate_bx$auth$validate_google_token(googleUser){
console.debug("Signing in with Google.....");

var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_26849){
var state_val_26850 = (state_26849[(1)]);
if((state_val_26850 === (1))){
var inst_26824 = (state_26849[(7)]);
var inst_26821 = googleUser.getBasicProfile();
var inst_26822 = inst_26821.getEmail();
var inst_26823 = googleUser.getAuthResponse();
var inst_26824__$1 = inst_26823.id_token;
var inst_26825 = icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$2(inst_26824__$1,inst_26821);
var state_26849__$1 = (function (){var statearr_26861 = state_26849;
(statearr_26861[(8)] = inst_26822);

(statearr_26861[(7)] = inst_26824__$1);

return statearr_26861;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_26849__$1,(2),inst_26825);
} else {
if((state_val_26850 === (2))){
var inst_26824 = (state_26849[(7)]);
var inst_26827 = (state_26849[(2)]);
var inst_26828 = new cljs.core.Keyword(null,"status","status",-1997798413).cljs$core$IFn$_invoke$arity$1(inst_26827);
var inst_26829 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26830 = [new cljs.core.Keyword(null,"body","body",-2049205669),new cljs.core.Keyword(null,"data","data",-232669377),new cljs.core.Keyword(null,"match_url","match_url",-1844276896)];
var inst_26831 = (new cljs.core.PersistentVector(null,3,(5),inst_26829,inst_26830,null));
var inst_26832 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(inst_26827,inst_26831);
var state_26849__$1 = (function (){var statearr_26862 = state_26849;
(statearr_26862[(9)] = inst_26832);

(statearr_26862[(10)] = inst_26828);

return statearr_26862;
})();
if(cljs.core.truth_(inst_26824)){
var statearr_26863_27068 = state_26849__$1;
(statearr_26863_27068[(1)] = (3));

} else {
var statearr_26864_27070 = state_26849__$1;
(statearr_26864_27070[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26850 === (3))){
var inst_26834 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.auth.auth_session,cljs.core.assoc,new cljs.core.Keyword("icurate-bx.auth","authenticated?","icurate-bx.auth/authenticated?",-1180388341),true);
var state_26849__$1 = state_26849;
var statearr_26866_27072 = state_26849__$1;
(statearr_26866_27072[(2)] = inst_26834);

(statearr_26866_27072[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26850 === (4))){
var state_26849__$1 = state_26849;
var statearr_26867_27073 = state_26849__$1;
(statearr_26867_27073[(2)] = null);

(statearr_26867_27073[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26850 === (5))){
var inst_26832 = (state_26849[(9)]);
var inst_26828 = (state_26849[(10)]);
var inst_26838 = (state_26849[(2)]);
var inst_26840 = cljs.core.count(inst_26832);
var inst_26841 = console.debug(inst_26840," latest bookmarks fetched.");
var inst_26842 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26844 = [inst_26828,inst_26832];
var inst_26845 = (new cljs.core.PersistentVector(null,2,(5),inst_26842,inst_26844,null));
var state_26849__$1 = (function (){var statearr_26868 = state_26849;
(statearr_26868[(11)] = inst_26838);

(statearr_26868[(12)] = inst_26841);

return statearr_26868;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_26849__$1,inst_26845);
} else {
return null;
}
}
}
}
}
});
return (function() {
var icurate_bx$auth$validate_google_token_$_state_machine__26357__auto__ = null;
var icurate_bx$auth$validate_google_token_$_state_machine__26357__auto____0 = (function (){
var statearr_26869 = [null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_26869[(0)] = icurate_bx$auth$validate_google_token_$_state_machine__26357__auto__);

(statearr_26869[(1)] = (1));

return statearr_26869;
});
var icurate_bx$auth$validate_google_token_$_state_machine__26357__auto____1 = (function (state_26849){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_26849);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e26870){var ex__26360__auto__ = e26870;
var statearr_26871_27081 = state_26849;
(statearr_26871_27081[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_26849[(4)]))){
var statearr_26872_27082 = state_26849;
(statearr_26872_27082[(1)] = cljs.core.first((state_26849[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27084 = state_26849;
state_26849 = G__27084;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$auth$validate_google_token_$_state_machine__26357__auto__ = function(state_26849){
switch(arguments.length){
case 0:
return icurate_bx$auth$validate_google_token_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$auth$validate_google_token_$_state_machine__26357__auto____1.call(this,state_26849);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$auth$validate_google_token_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$auth$validate_google_token_$_state_machine__26357__auto____0;
icurate_bx$auth$validate_google_token_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$auth$validate_google_token_$_state_machine__26357__auto____1;
return icurate_bx$auth$validate_google_token_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_26873 = f__26536__auto__();
(statearr_26873[(6)] = c__26535__auto__);

return statearr_26873;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
icurate_bx.auth.google_auth_url = (function (){var redirect_url = browser.identity.getRedirectURL();
var client_id = "935207098240-rs4g1ppugvmcvo5sake31nkaqc4a535u.apps.googleusercontent.com";
var scopes = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, ["openid","email","profile"], null);
var auth_url = ["https://accounts.google.com/o/oauth2/auth?client_id=",client_id,"&response_type=token&redirect_uri=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(encodeURIComponent(redirect_url)),"&scope=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(encodeURIComponent(clojure.string.join.cljs$core$IFn$_invoke$arity$2(" ",scopes)))].join('');
return auth_url;
})();
icurate_bx.auth.extract_access_token = (function icurate_bx$auth$extract_access_token(redirect_url){
if(((0) < clojure.string.index_of.cljs$core$IFn$_invoke$arity$2(redirect_url,"#"))){
var start_uri = clojure.string.index_of.cljs$core$IFn$_invoke$arity$2(redirect_url,"#");
var redirect_uri = cljs.core.subs.cljs$core$IFn$_invoke$arity$2(redirect_url,(start_uri + (1)));
var token_param = (new URLSearchParams(redirect_uri));
var access_token = token_param.get("access_token");
return cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(access_token)], 0));
} else {
return null;
}
});
icurate_bx.auth.validate_access_token = (function icurate_bx$auth$validate_access_token(redirect_url){
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_26889){
var state_val_26890 = (state_26889[(1)]);
if((state_val_26890 === (1))){
var inst_26874 = icurate_bx.auth.extract_access_token(redirect_url);
var inst_26875 = [cljs.core.str.cljs$core$IFn$_invoke$arity$1("https://www.googleapis.com/oauth2/v3/tokeninfo"),"?access_token=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_26874)].join('');
var inst_26876 = cljs_http.client.get(inst_26875);
var state_26889__$1 = state_26889;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_26889__$1,(2),inst_26876);
} else {
if((state_val_26890 === (2))){
var inst_26878 = (state_26889[(2)]);
var inst_26879 = new cljs.core.Keyword(null,"body","body",-2049205669).cljs$core$IFn$_invoke$arity$1(inst_26878);
var inst_26880 = cljs.core.clj__GT_js(inst_26879);
var inst_26881 = cljs.core.prn_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_26880], 0));
var inst_26882 = console.log(inst_26881);
var inst_26883 = new cljs.core.Keyword(null,"body","body",-2049205669).cljs$core$IFn$_invoke$arity$1(inst_26878);
var inst_26884 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26885 = [new cljs.core.Keyword(null,"email","email",1415816706),new cljs.core.Keyword(null,"aud","aud",357659490),new cljs.core.Keyword(null,"sub","sub",-2093760025),new cljs.core.Keyword(null,"exp","exp",-261706262),new cljs.core.Keyword(null,"email_verified","email_verified",238951503),new cljs.core.Keyword(null,"access_type","access_type",1154594737)];
var inst_26886 = (new cljs.core.PersistentVector(null,6,(5),inst_26884,inst_26885,null));
var inst_26887 = cljs.core.select_keys(inst_26883,inst_26886);
var state_26889__$1 = (function (){var statearr_26891 = state_26889;
(statearr_26891[(7)] = inst_26882);

return statearr_26891;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_26889__$1,inst_26887);
} else {
return null;
}
}
});
return (function() {
var icurate_bx$auth$validate_access_token_$_state_machine__26357__auto__ = null;
var icurate_bx$auth$validate_access_token_$_state_machine__26357__auto____0 = (function (){
var statearr_26892 = [null,null,null,null,null,null,null,null];
(statearr_26892[(0)] = icurate_bx$auth$validate_access_token_$_state_machine__26357__auto__);

(statearr_26892[(1)] = (1));

return statearr_26892;
});
var icurate_bx$auth$validate_access_token_$_state_machine__26357__auto____1 = (function (state_26889){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_26889);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e26893){var ex__26360__auto__ = e26893;
var statearr_26894_27093 = state_26889;
(statearr_26894_27093[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_26889[(4)]))){
var statearr_26895_27095 = state_26889;
(statearr_26895_27095[(1)] = cljs.core.first((state_26889[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27096 = state_26889;
state_26889 = G__27096;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$auth$validate_access_token_$_state_machine__26357__auto__ = function(state_26889){
switch(arguments.length){
case 0:
return icurate_bx$auth$validate_access_token_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$auth$validate_access_token_$_state_machine__26357__auto____1.call(this,state_26889);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$auth$validate_access_token_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$auth$validate_access_token_$_state_machine__26357__auto____0;
icurate_bx$auth$validate_access_token_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$auth$validate_access_token_$_state_machine__26357__auto____1;
return icurate_bx$auth$validate_access_token_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_26896 = f__26536__auto__();
(statearr_26896[(6)] = c__26535__auto__);

return statearr_26896;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
icurate_bx.auth.signin_with_google = (function icurate_bx$auth$signin_with_google(){
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_26951){
var state_val_26952 = (state_26951[(1)]);
if((state_val_26952 === (7))){
var inst_26929 = (state_26951[(2)]);
var inst_26930 = new cljs.core.Keyword(null,"status","status",-1997798413).cljs$core$IFn$_invoke$arity$1(inst_26929);
var inst_26931 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26933 = [new cljs.core.Keyword(null,"body","body",-2049205669),new cljs.core.Keyword(null,"data","data",-232669377),new cljs.core.Keyword(null,"match_url","match_url",-1844276896)];
var inst_26934 = (new cljs.core.PersistentVector(null,3,(5),inst_26931,inst_26933,null));
var inst_26935 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(inst_26929,inst_26934);
var inst_26936 = new cljs.core.Keyword(null,"status","status",-1997798413).cljs$core$IFn$_invoke$arity$1(inst_26929);
var inst_26937 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((200),inst_26936);
var state_26951__$1 = (function (){var statearr_26958 = state_26951;
(statearr_26958[(7)] = inst_26930);

(statearr_26958[(8)] = inst_26935);

return statearr_26958;
})();
if(inst_26937){
var statearr_26959_27101 = state_26951__$1;
(statearr_26959_27101[(1)] = (8));

} else {
var statearr_26960_27103 = state_26951__$1;
(statearr_26960_27103[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26952 === (1))){
var inst_26903 = browser.identity.launchWebAuthFlow(({"interactive": true, "url": icurate_bx.auth.google_auth_url}));
var inst_26904 = cljs.core.async.interop.p__GT_c(inst_26903);
var state_26951__$1 = state_26951;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_26951__$1,(2),inst_26904);
} else {
if((state_val_26952 === (4))){
var inst_26906 = (state_26951[(9)]);
var state_26951__$1 = state_26951;
var statearr_26961_27105 = state_26951__$1;
(statearr_26961_27105[(2)] = inst_26906);

(statearr_26961_27105[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26952 === (6))){
var inst_26922 = (state_26951[(10)]);
var inst_26925 = (state_26951[(2)]);
var inst_26927 = icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$2(inst_26922,inst_26925);
var state_26951__$1 = state_26951;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_26951__$1,(7),inst_26927);
} else {
if((state_val_26952 === (3))){
var inst_26906 = (state_26951[(9)]);
var inst_26918 = (function(){throw inst_26906})();
var state_26951__$1 = state_26951;
var statearr_26963_27110 = state_26951__$1;
(statearr_26963_27110[(2)] = inst_26918);

(statearr_26963_27110[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26952 === (2))){
var inst_26906 = (state_26951[(9)]);
var inst_26906__$1 = (state_26951[(2)]);
var inst_26912 = (inst_26906__$1 instanceof cljs.core.ExceptionInfo);
var inst_26913 = cljs.core.ex_data(inst_26906__$1);
var inst_26914 = new cljs.core.Keyword(null,"error","error",-978969032).cljs$core$IFn$_invoke$arity$1(inst_26913);
var inst_26915 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_26914,new cljs.core.Keyword(null,"promise-error","promise-error",-90673560));
var inst_26916 = ((inst_26912) && (inst_26915));
var state_26951__$1 = (function (){var statearr_26964 = state_26951;
(statearr_26964[(9)] = inst_26906__$1);

return statearr_26964;
})();
if(cljs.core.truth_(inst_26916)){
var statearr_26965_27120 = state_26951__$1;
(statearr_26965_27120[(1)] = (3));

} else {
var statearr_26966_27121 = state_26951__$1;
(statearr_26966_27121[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26952 === (9))){
var state_26951__$1 = state_26951;
var statearr_26967_27123 = state_26951__$1;
(statearr_26967_27123[(2)] = null);

(statearr_26967_27123[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_26952 === (5))){
var inst_26921 = (state_26951[(2)]);
var inst_26922 = icurate_bx.auth.extract_access_token(inst_26921);
var inst_26923 = icurate_bx.auth.validate_access_token(inst_26921);
var state_26951__$1 = (function (){var statearr_26973 = state_26951;
(statearr_26973[(10)] = inst_26922);

return statearr_26973;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_26951__$1,(6),inst_26923);
} else {
if((state_val_26952 === (10))){
var inst_26945 = (state_26951[(2)]);
var state_26951__$1 = state_26951;
return cljs.core.async.impl.ioc_helpers.return_chan(state_26951__$1,inst_26945);
} else {
if((state_val_26952 === (8))){
var inst_26930 = (state_26951[(7)]);
var inst_26935 = (state_26951[(8)]);
var inst_26940 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_26941 = [inst_26930,inst_26935];
var inst_26942 = (new cljs.core.PersistentVector(null,2,(5),inst_26940,inst_26941,null));
var state_26951__$1 = state_26951;
var statearr_26974_27127 = state_26951__$1;
(statearr_26974_27127[(2)] = inst_26942);

(statearr_26974_27127[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});
return (function() {
var icurate_bx$auth$signin_with_google_$_state_machine__26357__auto__ = null;
var icurate_bx$auth$signin_with_google_$_state_machine__26357__auto____0 = (function (){
var statearr_26975 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_26975[(0)] = icurate_bx$auth$signin_with_google_$_state_machine__26357__auto__);

(statearr_26975[(1)] = (1));

return statearr_26975;
});
var icurate_bx$auth$signin_with_google_$_state_machine__26357__auto____1 = (function (state_26951){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_26951);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e26976){var ex__26360__auto__ = e26976;
var statearr_26977_27132 = state_26951;
(statearr_26977_27132[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_26951[(4)]))){
var statearr_26978_27133 = state_26951;
(statearr_26978_27133[(1)] = cljs.core.first((state_26951[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27135 = state_26951;
state_26951 = G__27135;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$auth$signin_with_google_$_state_machine__26357__auto__ = function(state_26951){
switch(arguments.length){
case 0:
return icurate_bx$auth$signin_with_google_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$auth$signin_with_google_$_state_machine__26357__auto____1.call(this,state_26951);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$auth$signin_with_google_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$auth$signin_with_google_$_state_machine__26357__auto____0;
icurate_bx$auth$signin_with_google_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$auth$signin_with_google_$_state_machine__26357__auto____1;
return icurate_bx$auth$signin_with_google_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_26979 = f__26536__auto__();
(statearr_26979[(6)] = c__26535__auto__);

return statearr_26979;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});

//# sourceMappingURL=icurate_bx.auth.js.map
