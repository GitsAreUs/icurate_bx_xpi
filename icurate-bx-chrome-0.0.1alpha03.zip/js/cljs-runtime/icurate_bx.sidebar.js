goog.provide('icurate_bx.sidebar');
var module$node_modules$material_ui_search_bar$lib$index=shadow.js.require("module$node_modules$material_ui_search_bar$lib$index", {});
icurate_bx.sidebar.react_keys = cljs.core.atom.cljs$core$IFn$_invoke$arity$1((0));
icurate_bx.sidebar.r_id = (function icurate_bx$sidebar$r_id(){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(icurate_bx.sidebar.react_keys,cljs.core.inc);
});
icurate_bx.sidebar.browser = icurate_bx.bookmark.get_browser_object.cljs$core$IFn$_invoke$arity$0();
icurate_bx.sidebar.card_primary_action = (function icurate_bx$sidebar$card_primary_action(url,title,summary){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-card__primary-action"], null),new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"card-header"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"card-icon material-icons"], null),"bookmark"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"card-title"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"h3","h3",2067611163),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-typography--headline6"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"a","a",-2123407586),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"href","href",-793805698),url], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"span","span",1394872991),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button__label"], null),title], null)], null)], null)], null)], null)], null);
});
icurate_bx.sidebar.card_body = (function icurate_bx$sidebar$card_body(summary){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"card-body__secondary mdc-typography mdc-typography--body2"], null),summary], null);
});
icurate_bx.sidebar.card_action_icons = (function icurate_bx$sidebar$card_action_icons(){
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-card__action-icons"], null),new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-icon-button mdc-card__action mdc-card__action--icon--unbounded",new cljs.core.Keyword(null,"aria-pressed","aria-pressed",-1749058631),"false",new cljs.core.Keyword(null,"aria-label","aria-label",455891514),"Add to favorites",new cljs.core.Keyword(null,"title","title",636505583),"Add to Favorites"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"i","i",-1386841315),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"material-icons mdc-icon-button__icon mdc-icon-button__icon--on"], null),"favorite"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"i","i",-1386841315),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"material-icons mdc-icon-button__icon mdc-icon-button__icon--on"], null),"favorite_border"], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"class","class",-2030961996),"material-icons mdc-icon-button mdc-card__action mdc-card__action--icon",new cljs.core.Keyword(null,"title","title",636505583),"Share"], null),"share"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"class","class",-2030961996),"material-icons mdc-icon-button mdc-card__action mdc-card__action--icon",new cljs.core.Keyword(null,"title","title",636505583),"More options"], null),"more_vert"], null)], null);
});
icurate_bx.sidebar.card_action_button = (function icurate_bx$sidebar$card_action_button(){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-card__actions"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-card__action-buttons"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button mdc-card__action mdc-card__action--button"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"span","span",1394872991),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button__label"], null),"Edit"], null)], null)], null),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.card_action_icons], null)], null);
});
icurate_bx.sidebar.mdc_card = (function icurate_bx$sidebar$mdc_card(key,url,title,summary){
var summary__$1 = (((summary == null))?"":summary);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"li","li",723558921),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),key,new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-image-list__item"], null),new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-card"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.card_primary_action,url,title], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.card_body,summary__$1], null),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.card_action_button], null),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"br","br",934104792)], null)], null)], null);
});
icurate_bx.sidebar.curated = (function icurate_bx$sidebar$curated(user_id,search_str){
var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_27534){
var state_val_27535 = (state_27534[(1)]);
if((state_val_27535 === (1))){
var inst_27516 = [new cljs.core.Keyword(null,"with-credentials?","with-credentials?",-1773202222),new cljs.core.Keyword(null,"query-params","query-params",900640534)];
var inst_27517 = ["query"];
var inst_27518 = ["{match_url(search: \"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(search_str),"\"){id url title summary}}"].join('');
var inst_27519 = [inst_27518];
var inst_27520 = cljs.core.PersistentHashMap.fromArrays(inst_27517,inst_27519);
var inst_27521 = [true,inst_27520];
var inst_27522 = cljs.core.PersistentHashMap.fromArrays(inst_27516,inst_27521);
var inst_27523 = cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(icurate_bx.bookmark.gql_ep,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_27522], 0));
var state_27534__$1 = state_27534;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_27534__$1,(2),inst_27523);
} else {
if((state_val_27535 === (2))){
var inst_27525 = (state_27534[(2)]);
var inst_27526 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_27527 = [new cljs.core.Keyword(null,"body","body",-2049205669),new cljs.core.Keyword(null,"data","data",-232669377),new cljs.core.Keyword(null,"match_url","match_url",-1844276896)];
var inst_27528 = (new cljs.core.PersistentVector(null,3,(5),inst_27526,inst_27527,null));
var inst_27529 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(inst_27525,inst_27528);
var inst_27530 = console.log("Search string: ",search_str);
var inst_27531 = cljs.core.count(inst_27529);
var inst_27532 = console.log("Response length: ",inst_27531);
var state_27534__$1 = (function (){var statearr_27541 = state_27534;
(statearr_27541[(7)] = inst_27530);

(statearr_27541[(8)] = inst_27532);

return statearr_27541;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_27534__$1,inst_27529);
} else {
return null;
}
}
});
return (function() {
var icurate_bx$sidebar$curated_$_state_machine__26357__auto__ = null;
var icurate_bx$sidebar$curated_$_state_machine__26357__auto____0 = (function (){
var statearr_27544 = [null,null,null,null,null,null,null,null,null];
(statearr_27544[(0)] = icurate_bx$sidebar$curated_$_state_machine__26357__auto__);

(statearr_27544[(1)] = (1));

return statearr_27544;
});
var icurate_bx$sidebar$curated_$_state_machine__26357__auto____1 = (function (state_27534){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_27534);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e27545){var ex__26360__auto__ = e27545;
var statearr_27546_27728 = state_27534;
(statearr_27546_27728[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_27534[(4)]))){
var statearr_27547_27729 = state_27534;
(statearr_27547_27729[(1)] = cljs.core.first((state_27534[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27730 = state_27534;
state_27534 = G__27730;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$sidebar$curated_$_state_machine__26357__auto__ = function(state_27534){
switch(arguments.length){
case 0:
return icurate_bx$sidebar$curated_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$sidebar$curated_$_state_machine__26357__auto____1.call(this,state_27534);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$sidebar$curated_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$sidebar$curated_$_state_machine__26357__auto____0;
icurate_bx$sidebar$curated_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$sidebar$curated_$_state_machine__26357__auto____1;
return icurate_bx$sidebar$curated_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_27551 = f__26536__auto__();
(statearr_27551[(6)] = c__26535__auto__);

return statearr_27551;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
icurate_bx.sidebar.search_text = reagent.core.atom.cljs$core$IFn$_invoke$arity$1("");
icurate_bx.sidebar.bms = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY);
icurate_bx.sidebar.done_typing = (100);
icurate_bx.sidebar.type_intvl = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY);
icurate_bx.sidebar.do_search = (function icurate_bx$sidebar$do_search(){
clearTimeout(cljs.core.deref(icurate_bx.sidebar.type_intvl));

var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_27564){
var state_val_27565 = (state_27564[(1)]);
if((state_val_27565 === (1))){
var inst_27556 = cljs.core.deref(icurate_bx.sidebar.search_text);
var inst_27557 = icurate_bx.sidebar.curated("1",inst_27556);
var state_27564__$1 = state_27564;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_27564__$1,(2),inst_27557);
} else {
if((state_val_27565 === (2))){
var inst_27559 = (state_27564[(2)]);
var inst_27560 = cljs.core.vec(inst_27559);
var inst_27561 = cljs.core.reset_BANG_(icurate_bx.sidebar.bms,inst_27560);
var inst_27562 = (icurate_bx.sidebar.render_cards.cljs$core$IFn$_invoke$arity$0 ? icurate_bx.sidebar.render_cards.cljs$core$IFn$_invoke$arity$0() : icurate_bx.sidebar.render_cards.call(null));
var state_27564__$1 = (function (){var statearr_27568 = state_27564;
(statearr_27568[(7)] = inst_27561);

return statearr_27568;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_27564__$1,inst_27562);
} else {
return null;
}
}
});
return (function() {
var icurate_bx$sidebar$do_search_$_state_machine__26357__auto__ = null;
var icurate_bx$sidebar$do_search_$_state_machine__26357__auto____0 = (function (){
var statearr_27569 = [null,null,null,null,null,null,null,null];
(statearr_27569[(0)] = icurate_bx$sidebar$do_search_$_state_machine__26357__auto__);

(statearr_27569[(1)] = (1));

return statearr_27569;
});
var icurate_bx$sidebar$do_search_$_state_machine__26357__auto____1 = (function (state_27564){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_27564);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e27571){var ex__26360__auto__ = e27571;
var statearr_27572_27731 = state_27564;
(statearr_27572_27731[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_27564[(4)]))){
var statearr_27574_27732 = state_27564;
(statearr_27574_27732[(1)] = cljs.core.first((state_27564[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27733 = state_27564;
state_27564 = G__27733;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$sidebar$do_search_$_state_machine__26357__auto__ = function(state_27564){
switch(arguments.length){
case 0:
return icurate_bx$sidebar$do_search_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$sidebar$do_search_$_state_machine__26357__auto____1.call(this,state_27564);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$sidebar$do_search_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$sidebar$do_search_$_state_machine__26357__auto____0;
icurate_bx$sidebar$do_search_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$sidebar$do_search_$_state_machine__26357__auto____1;
return icurate_bx$sidebar$do_search_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_27577 = f__26536__auto__();
(statearr_27577[(6)] = c__26535__auto__);

return statearr_27577;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
icurate_bx.sidebar.search_bar = (function icurate_bx$sidebar$search_bar(kws,bms){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [reagent.core.adapt_react_class(module$node_modules$material_ui_search_bar$lib$index.default),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"value","value",305978217),cljs.core.deref(kws),new cljs.core.Keyword(null,"onChange","onChange",-312891301),(function (p1__27579_SHARP_){
return cljs.core.reset_BANG_(kws,p1__27579_SHARP_);
}),new cljs.core.Keyword(null,"onCancelSearch","onCancelSearch",-770283352),(function (){
cljs.core.reset_BANG_(kws,"");

return icurate_bx.sidebar.do_search();
}),new cljs.core.Keyword(null,"onRequestSearch","onRequestSearch",1390732165),(function (){
return icurate_bx.sidebar.do_search();
}),new cljs.core.Keyword(null,"style","style",-496642736),({"margin": "50 left", "maxWidth": (800)})], null)], null);
});
icurate_bx.sidebar.render_search = (function icurate_bx$sidebar$render_search(){
return reagent.core.render.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.search_bar,icurate_bx.sidebar.search_text,icurate_bx.sidebar.bms], null),document.getElementById("search"));
});
icurate_bx.sidebar.curated_bm = (function icurate_bx$sidebar$curated_bm(bms){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632)], null),cljs.core.interleave.cljs$core$IFn$_invoke$arity$2(cljs.core.repeatedly.cljs$core$IFn$_invoke$arity$1((function (){
return cljs.core.identity(cljs.core.with_meta(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"br","br",934104792)], null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"key","key",-1516042587),icurate_bx.sidebar.r_id()], null)));
})),(function (){var iter__4529__auto__ = (function icurate_bx$sidebar$curated_bm_$_iter__27584(s__27585){
return (new cljs.core.LazySeq(null,(function (){
var s__27585__$1 = s__27585;
while(true){
var temp__5735__auto__ = cljs.core.seq(s__27585__$1);
if(temp__5735__auto__){
var s__27585__$2 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(s__27585__$2)){
var c__4527__auto__ = cljs.core.chunk_first(s__27585__$2);
var size__4528__auto__ = cljs.core.count(c__4527__auto__);
var b__27587 = cljs.core.chunk_buffer(size__4528__auto__);
if((function (){var i__27586 = (0);
while(true){
if((i__27586 < size__4528__auto__)){
var bm = cljs.core._nth(c__4527__auto__,i__27586);
cljs.core.chunk_append(b__27587,(function (){var map__27592 = bm;
var map__27592__$1 = (((((!((map__27592 == null))))?(((((map__27592.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27592.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27592):map__27592);
var id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27592__$1,new cljs.core.Keyword(null,"id","id",-1388402092));
var url = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27592__$1,new cljs.core.Keyword(null,"url","url",276297046));
var title = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27592__$1,new cljs.core.Keyword(null,"title","title",636505583));
var summary = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27592__$1,new cljs.core.Keyword(null,"summary","summary",380847952));
return cljs.core.with_meta(new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.mdc_card,id,url,title,summary], null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"key","key",-1516042587),(parseInt(id) + cljs.core.rand_int((1000)))], null));
})());

var G__27734 = (i__27586 + (1));
i__27586 = G__27734;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__27587),icurate_bx$sidebar$curated_bm_$_iter__27584(cljs.core.chunk_rest(s__27585__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__27587),null);
}
} else {
var bm = cljs.core.first(s__27585__$2);
return cljs.core.cons((function (){var map__27597 = bm;
var map__27597__$1 = (((((!((map__27597 == null))))?(((((map__27597.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27597.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27597):map__27597);
var id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27597__$1,new cljs.core.Keyword(null,"id","id",-1388402092));
var url = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27597__$1,new cljs.core.Keyword(null,"url","url",276297046));
var title = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27597__$1,new cljs.core.Keyword(null,"title","title",636505583));
var summary = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27597__$1,new cljs.core.Keyword(null,"summary","summary",380847952));
return cljs.core.with_meta(new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.mdc_card,id,url,title,summary], null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"key","key",-1516042587),(parseInt(id) + cljs.core.rand_int((1000)))], null));
})(),icurate_bx$sidebar$curated_bm_$_iter__27584(cljs.core.rest(s__27585__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4529__auto__(bms);
})()));
});
icurate_bx.sidebar.render_cards = (function icurate_bx$sidebar$render_cards(){
return reagent.core.render.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [icurate_bx.sidebar.curated_bm,cljs.core.deref(icurate_bx.sidebar.bms)], null),document.getElementById("sidebar"));
});
icurate_bx.sidebar.render_google_button = (function icurate_bx$sidebar$render_google_button(){
return gapi.signin2.render("g-signin2",({"scope": "profile email", "width": (240), "height": (50), "longtitle": true, "theme": "light", "onsuccess": icurate_bx.sidebar.googleSignIn, "onfailure": (function (){
return console.log("Google authentication failed!");
})}));
});
icurate_bx.sidebar.googleSignIn = (function icurate_bx$sidebar$googleSignIn(googleUser){
console.debug("Credential provided! Authenticating....");

var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_27632){
var state_val_27633 = (state_27632[(1)]);
if((state_val_27633 === (1))){
var inst_27611 = icurate_bx.auth.validate_google_token(googleUser);
var state_27632__$1 = state_27632;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_27632__$1,(2),inst_27611);
} else {
if((state_val_27633 === (2))){
var inst_27613 = (state_27632[(2)]);
var inst_27614 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_27613,(0),null);
var inst_27615 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_27613,(1),null);
var inst_27617 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_27614,(200));
var state_27632__$1 = (function (){var statearr_27637 = state_27632;
(statearr_27637[(7)] = inst_27615);

return statearr_27637;
})();
if(inst_27617){
var statearr_27638_27735 = state_27632__$1;
(statearr_27638_27735[(1)] = (3));

} else {
var statearr_27639_27736 = state_27632__$1;
(statearr_27639_27736[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_27633 === (3))){
var inst_27615 = (state_27632[(7)]);
var inst_27619 = document.getElementById("g-signin2");
var inst_27620 = inst_27619.style;
var inst_27621 = (inst_27620.display = "none");
var inst_27623 = cljs.core.reset_BANG_(icurate_bx.sidebar.bms,inst_27615);
var inst_27624 = icurate_bx.sidebar.render_search();
var inst_27625 = icurate_bx.sidebar.render_cards();
var inst_27626 = console.log("Background start indexer.....");
var state_27632__$1 = (function (){var statearr_27643 = state_27632;
(statearr_27643[(8)] = inst_27624);

(statearr_27643[(9)] = inst_27623);

(statearr_27643[(10)] = inst_27621);

(statearr_27643[(11)] = inst_27625);

return statearr_27643;
})();
var statearr_27644_27737 = state_27632__$1;
(statearr_27644_27737[(2)] = inst_27626);

(statearr_27644_27737[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_27633 === (4))){
var state_27632__$1 = state_27632;
var statearr_27645_27738 = state_27632__$1;
(statearr_27645_27738[(2)] = null);

(statearr_27645_27738[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_27633 === (5))){
var inst_27630 = (state_27632[(2)]);
var state_27632__$1 = state_27632;
return cljs.core.async.impl.ioc_helpers.return_chan(state_27632__$1,inst_27630);
} else {
return null;
}
}
}
}
}
});
return (function() {
var icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto__ = null;
var icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto____0 = (function (){
var statearr_27646 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_27646[(0)] = icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto__);

(statearr_27646[(1)] = (1));

return statearr_27646;
});
var icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto____1 = (function (state_27632){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_27632);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e27649){var ex__26360__auto__ = e27649;
var statearr_27650_27739 = state_27632;
(statearr_27650_27739[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_27632[(4)]))){
var statearr_27652_27740 = state_27632;
(statearr_27652_27740[(1)] = cljs.core.first((state_27632[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27741 = state_27632;
state_27632 = G__27741;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto__ = function(state_27632){
switch(arguments.length){
case 0:
return icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto____1.call(this,state_27632);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto____0;
icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto____1;
return icurate_bx$sidebar$googleSignIn_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_27654 = f__26536__auto__();
(statearr_27654[(6)] = c__26535__auto__);

return statearr_27654;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
goog.exportSymbol('icurate_bx.sidebar.googleSignIn', icurate_bx.sidebar.googleSignIn);
icurate_bx.sidebar.signin_with_google = (function icurate_bx$sidebar$signin_with_google(){
console.log("Signing in with google");

var c__26535__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_27677){
var state_val_27678 = (state_27677[(1)]);
if((state_val_27678 === (1))){
var inst_27662 = icurate_bx.auth.signin_with_google();
var state_27677__$1 = state_27677;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_27677__$1,(2),inst_27662);
} else {
if((state_val_27678 === (2))){
var inst_27664 = (state_27677[(2)]);
var inst_27665 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_27664,(0),null);
var inst_27666 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_27664,(1),null);
var inst_27667 = document.getElementById("g-signin2");
var inst_27668 = inst_27667.style;
var inst_27669 = (inst_27668.display = "none");
var inst_27670 = cljs.core.reset_BANG_(icurate_bx.sidebar.bms,inst_27666);
var inst_27671 = icurate_bx.sidebar.render_search();
var inst_27672 = icurate_bx.sidebar.render_cards();
var inst_27673 = console.log("Background start indexer.....");
var inst_27674 = icurate_bx.sidebar.browser.runtime;
var inst_27675 = inst_27674.sendMessage(({"to": "background", "cmd": "start-curator"}));
var state_27677__$1 = (function (){var statearr_27687 = state_27677;
(statearr_27687[(7)] = inst_27665);

(statearr_27687[(8)] = inst_27670);

(statearr_27687[(9)] = inst_27669);

(statearr_27687[(10)] = inst_27673);

(statearr_27687[(11)] = inst_27675);

(statearr_27687[(12)] = inst_27672);

(statearr_27687[(13)] = inst_27671);

return statearr_27687;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_27677__$1,true);
} else {
return null;
}
}
});
return (function() {
var icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto__ = null;
var icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto____0 = (function (){
var statearr_27688 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_27688[(0)] = icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto__);

(statearr_27688[(1)] = (1));

return statearr_27688;
});
var icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto____1 = (function (state_27677){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_27677);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e27689){var ex__26360__auto__ = e27689;
var statearr_27690_27742 = state_27677;
(statearr_27690_27742[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_27677[(4)]))){
var statearr_27691_27743 = state_27677;
(statearr_27691_27743[(1)] = cljs.core.first((state_27677[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27744 = state_27677;
state_27677 = G__27744;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto__ = function(state_27677){
switch(arguments.length){
case 0:
return icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto____1.call(this,state_27677);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto____0;
icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto____1;
return icurate_bx$sidebar$signin_with_google_$_state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_27692 = f__26536__auto__();
(statearr_27692[(6)] = c__26535__auto__);

return statearr_27692;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));

return c__26535__auto__;
});
icurate_bx.sidebar.gsign_div = (function icurate_bx$sidebar$gsign_div(){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-touch-target-wrapper"], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button mdc-button--touch",new cljs.core.Keyword(null,"onClick","onClick",-1991238530),icurate_bx.sidebar.signin_with_google], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button__ripple"], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"span","span",1394872991),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button__label"], null),"SignIn With Google"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"class","class",-2030961996),"mdc-button__touch"], null)], null)], null)], null);
});
var c__26535__auto___27745 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__26536__auto__ = (function (){var switch__26356__auto__ = (function (state_27715){
var state_val_27716 = (state_27715[(1)]);
if((state_val_27716 === (1))){
var inst_27696 = icurate_bx.auth.latest_bookmarks.cljs$core$IFn$_invoke$arity$0();
var state_27715__$1 = state_27715;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_27715__$1,(2),inst_27696);
} else {
if((state_val_27716 === (2))){
var inst_27698 = (state_27715[(2)]);
var inst_27699 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_27698,(0),null);
var inst_27700 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_27698,(1),null);
var inst_27701 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_27699,(200));
var state_27715__$1 = (function (){var statearr_27717 = state_27715;
(statearr_27717[(7)] = inst_27700);

return statearr_27717;
})();
if(inst_27701){
var statearr_27718_27746 = state_27715__$1;
(statearr_27718_27746[(1)] = (3));

} else {
var statearr_27719_27747 = state_27715__$1;
(statearr_27719_27747[(1)] = (4));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_27716 === (3))){
var inst_27700 = (state_27715[(7)]);
var inst_27703 = cljs.core.reset_BANG_(icurate_bx.sidebar.bms,inst_27700);
var inst_27704 = icurate_bx.sidebar.render_search();
var inst_27705 = icurate_bx.sidebar.render_cards();
var inst_27706 = icurate_bx.sidebar.browser.runtime;
var inst_27707 = inst_27706.sendMessage(({"to": "background", "cmd": "start-curator"}));
var state_27715__$1 = (function (){var statearr_27720 = state_27715;
(statearr_27720[(8)] = inst_27703);

(statearr_27720[(9)] = inst_27704);

(statearr_27720[(10)] = inst_27705);

return statearr_27720;
})();
var statearr_27721_27748 = state_27715__$1;
(statearr_27721_27748[(2)] = inst_27707);

(statearr_27721_27748[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_27716 === (4))){
var inst_27709 = icurate_bx.sidebar.gsign_div();
var inst_27710 = document.getElementById("g-signin2");
var inst_27711 = reagent.core.render.cljs$core$IFn$_invoke$arity$2(inst_27709,inst_27710);
var state_27715__$1 = state_27715;
var statearr_27722_27749 = state_27715__$1;
(statearr_27722_27749[(2)] = inst_27711);

(statearr_27722_27749[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_27716 === (5))){
var inst_27713 = (state_27715[(2)]);
var state_27715__$1 = state_27715;
return cljs.core.async.impl.ioc_helpers.return_chan(state_27715__$1,inst_27713);
} else {
return null;
}
}
}
}
}
});
return (function() {
var icurate_bx$sidebar$state_machine__26357__auto__ = null;
var icurate_bx$sidebar$state_machine__26357__auto____0 = (function (){
var statearr_27723 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_27723[(0)] = icurate_bx$sidebar$state_machine__26357__auto__);

(statearr_27723[(1)] = (1));

return statearr_27723;
});
var icurate_bx$sidebar$state_machine__26357__auto____1 = (function (state_27715){
while(true){
var ret_value__26358__auto__ = (function (){try{while(true){
var result__26359__auto__ = switch__26356__auto__(state_27715);
if(cljs.core.keyword_identical_QMARK_(result__26359__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__26359__auto__;
}
break;
}
}catch (e27724){var ex__26360__auto__ = e27724;
var statearr_27725_27750 = state_27715;
(statearr_27725_27750[(2)] = ex__26360__auto__);


if(cljs.core.seq((state_27715[(4)]))){
var statearr_27726_27751 = state_27715;
(statearr_27726_27751[(1)] = cljs.core.first((state_27715[(4)])));

} else {
throw ex__26360__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__26358__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__27752 = state_27715;
state_27715 = G__27752;
continue;
} else {
return ret_value__26358__auto__;
}
break;
}
});
icurate_bx$sidebar$state_machine__26357__auto__ = function(state_27715){
switch(arguments.length){
case 0:
return icurate_bx$sidebar$state_machine__26357__auto____0.call(this);
case 1:
return icurate_bx$sidebar$state_machine__26357__auto____1.call(this,state_27715);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
icurate_bx$sidebar$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$0 = icurate_bx$sidebar$state_machine__26357__auto____0;
icurate_bx$sidebar$state_machine__26357__auto__.cljs$core$IFn$_invoke$arity$1 = icurate_bx$sidebar$state_machine__26357__auto____1;
return icurate_bx$sidebar$state_machine__26357__auto__;
})()
})();
var state__26537__auto__ = (function (){var statearr_27727 = f__26536__auto__();
(statearr_27727[(6)] = c__26535__auto___27745);

return statearr_27727;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__26537__auto__);
}));


//# sourceMappingURL=icurate_bx.sidebar.js.map
