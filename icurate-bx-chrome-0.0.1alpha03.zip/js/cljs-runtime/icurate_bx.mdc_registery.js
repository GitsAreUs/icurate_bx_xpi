goog.provide('icurate_bx.mdc_registery');
icurate_bx.mdc_registery.mdcs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
icurate_bx.mdc_registery.mdc_register = (function icurate_bx$mdc_registery$mdc_register(name,f){
if(cljs.core.fn_QMARK_(f)){
} else {
throw cljs.core.ex_info.cljs$core$IFn$_invoke$arity$2([cljs.core.str.cljs$core$IFn$_invoke$arity$1(f),"must be a fn to hoist ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(name)].join(''),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"cause","cause",231901252),"f is not a function",new cljs.core.Keyword(null,"f","f",-1597136552),f], null));
}

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.mdc_registery.mdcs,cljs.core.assoc,name,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"mdc","mdc",-1159810648),f,new cljs.core.Keyword(null,"init?","init?",438181499),false], null));
});
/**
 * TODO: Optimize this
 */
icurate_bx.mdc_registery.materialize = (function icurate_bx$mdc_registery$materialize(){
var seq__33128 = cljs.core.seq(cljs.core.deref(icurate_bx.mdc_registery.mdcs));
var chunk__33129 = null;
var count__33130 = (0);
var i__33131 = (0);
while(true){
if((i__33131 < count__33130)){
var vec__33166 = chunk__33129.cljs$core$IIndexed$_nth$arity$2(null,i__33131);
var name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33166,(0),null);
var map__33169 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33166,(1),null);
var map__33169__$1 = (((((!((map__33169 == null))))?(((((map__33169.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__33169.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__33169):map__33169);
var mdc = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__33169__$1,new cljs.core.Keyword(null,"mdc","mdc",-1159810648));
var init_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__33169__$1,new cljs.core.Keyword(null,"init?","init?",438181499));
if(cljs.core.truth_(init_QMARK_)){
} else {
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.mdc_registery.mdcs,cljs.core.assoc,name,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"mdc","mdc",-1159810648),(mdc.cljs$core$IFn$_invoke$arity$0 ? mdc.cljs$core$IFn$_invoke$arity$0() : mdc.call(null)),new cljs.core.Keyword(null,"init?","init?",438181499),true], null));
}


var G__33222 = seq__33128;
var G__33223 = chunk__33129;
var G__33224 = count__33130;
var G__33225 = (i__33131 + (1));
seq__33128 = G__33222;
chunk__33129 = G__33223;
count__33130 = G__33224;
i__33131 = G__33225;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__33128);
if(temp__5735__auto__){
var seq__33128__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__33128__$1)){
var c__4556__auto__ = cljs.core.chunk_first(seq__33128__$1);
var G__33232 = cljs.core.chunk_rest(seq__33128__$1);
var G__33233 = c__4556__auto__;
var G__33234 = cljs.core.count(c__4556__auto__);
var G__33235 = (0);
seq__33128 = G__33232;
chunk__33129 = G__33233;
count__33130 = G__33234;
i__33131 = G__33235;
continue;
} else {
var vec__33185 = cljs.core.first(seq__33128__$1);
var name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33185,(0),null);
var map__33188 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33185,(1),null);
var map__33188__$1 = (((((!((map__33188 == null))))?(((((map__33188.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__33188.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__33188):map__33188);
var mdc = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__33188__$1,new cljs.core.Keyword(null,"mdc","mdc",-1159810648));
var init_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__33188__$1,new cljs.core.Keyword(null,"init?","init?",438181499));
if(cljs.core.truth_(init_QMARK_)){
} else {
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.mdc_registery.mdcs,cljs.core.assoc,name,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"mdc","mdc",-1159810648),(mdc.cljs$core$IFn$_invoke$arity$0 ? mdc.cljs$core$IFn$_invoke$arity$0() : mdc.call(null)),new cljs.core.Keyword(null,"init?","init?",438181499),true], null));
}


var G__33242 = cljs.core.next(seq__33128__$1);
var G__33243 = null;
var G__33244 = (0);
var G__33245 = (0);
seq__33128 = G__33242;
chunk__33129 = G__33243;
count__33130 = G__33244;
i__33131 = G__33245;
continue;
}
} else {
return null;
}
}
break;
}
});

//# sourceMappingURL=icurate_bx.mdc_registery.js.map
