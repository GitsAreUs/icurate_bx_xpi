goog.provide('shadow.cljs.devtools.client.browser');
shadow.cljs.devtools.client.browser.devtools_msg = (function shadow$cljs$devtools$client$browser$devtools_msg(var_args){
var args__4742__auto__ = [];
var len__4736__auto___36706 = arguments.length;
var i__4737__auto___36707 = (0);
while(true){
if((i__4737__auto___36707 < len__4736__auto___36706)){
args__4742__auto__.push((arguments[i__4737__auto___36707]));

var G__36709 = (i__4737__auto___36707 + (1));
i__4737__auto___36707 = G__36709;
continue;
} else {
}
break;
}

var argseq__4743__auto__ = ((((1) < args__4742__auto__.length))?(new cljs.core.IndexedSeq(args__4742__auto__.slice((1)),(0),null)):null);
return shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4743__auto__);
});

(shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic = (function (msg,args){
if(cljs.core.seq(shadow.cljs.devtools.client.env.log_style)){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.into.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [["%cshadow-cljs: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg)].join(''),shadow.cljs.devtools.client.env.log_style], null),args)));
} else {
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.into.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [["shadow-cljs: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg)].join('')], null),args)));
}
}));

(shadow.cljs.devtools.client.browser.devtools_msg.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(shadow.cljs.devtools.client.browser.devtools_msg.cljs$lang$applyTo = (function (seq36286){
var G__36287 = cljs.core.first(seq36286);
var seq36286__$1 = cljs.core.next(seq36286);
var self__4723__auto__ = this;
return self__4723__auto__.cljs$core$IFn$_invoke$arity$variadic(G__36287,seq36286__$1);
}));

shadow.cljs.devtools.client.browser.script_eval = (function shadow$cljs$devtools$client$browser$script_eval(code){
return goog.globalEval(code);
});
shadow.cljs.devtools.client.browser.do_js_load = (function shadow$cljs$devtools$client$browser$do_js_load(sources){
var seq__36290 = cljs.core.seq(sources);
var chunk__36291 = null;
var count__36292 = (0);
var i__36293 = (0);
while(true){
if((i__36293 < count__36292)){
var map__36302 = chunk__36291.cljs$core$IIndexed$_nth$arity$2(null,i__36293);
var map__36302__$1 = (((((!((map__36302 == null))))?(((((map__36302.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36302.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36302):map__36302);
var src = map__36302__$1;
var resource_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36302__$1,new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582));
var output_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36302__$1,new cljs.core.Keyword(null,"output-name","output-name",-1769107767));
var resource_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36302__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
var js = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36302__$1,new cljs.core.Keyword(null,"js","js",1768080579));
$CLJS.SHADOW_ENV.setLoaded(output_name);

shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load JS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([resource_name], 0));

shadow.cljs.devtools.client.env.before_load_src(src);

try{shadow.cljs.devtools.client.browser.script_eval([cljs.core.str.cljs$core$IFn$_invoke$arity$1(js),"\n//# sourceURL=",cljs.core.str.cljs$core$IFn$_invoke$arity$1($CLJS.SHADOW_ENV.scriptBase),cljs.core.str.cljs$core$IFn$_invoke$arity$1(output_name)].join(''));
}catch (e36304){var e_36716 = e36304;
console.error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name)].join(''),e_36716);

throw (new Error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name),": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(e_36716.message)].join('')));
}

var G__36719 = seq__36290;
var G__36720 = chunk__36291;
var G__36721 = count__36292;
var G__36722 = (i__36293 + (1));
seq__36290 = G__36719;
chunk__36291 = G__36720;
count__36292 = G__36721;
i__36293 = G__36722;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__36290);
if(temp__5735__auto__){
var seq__36290__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__36290__$1)){
var c__4556__auto__ = cljs.core.chunk_first(seq__36290__$1);
var G__36727 = cljs.core.chunk_rest(seq__36290__$1);
var G__36728 = c__4556__auto__;
var G__36729 = cljs.core.count(c__4556__auto__);
var G__36730 = (0);
seq__36290 = G__36727;
chunk__36291 = G__36728;
count__36292 = G__36729;
i__36293 = G__36730;
continue;
} else {
var map__36305 = cljs.core.first(seq__36290__$1);
var map__36305__$1 = (((((!((map__36305 == null))))?(((((map__36305.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36305.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36305):map__36305);
var src = map__36305__$1;
var resource_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36305__$1,new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582));
var output_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36305__$1,new cljs.core.Keyword(null,"output-name","output-name",-1769107767));
var resource_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36305__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
var js = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36305__$1,new cljs.core.Keyword(null,"js","js",1768080579));
$CLJS.SHADOW_ENV.setLoaded(output_name);

shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load JS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([resource_name], 0));

shadow.cljs.devtools.client.env.before_load_src(src);

try{shadow.cljs.devtools.client.browser.script_eval([cljs.core.str.cljs$core$IFn$_invoke$arity$1(js),"\n//# sourceURL=",cljs.core.str.cljs$core$IFn$_invoke$arity$1($CLJS.SHADOW_ENV.scriptBase),cljs.core.str.cljs$core$IFn$_invoke$arity$1(output_name)].join(''));
}catch (e36307){var e_36734 = e36307;
console.error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name)].join(''),e_36734);

throw (new Error(["Failed to load ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name),": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(e_36734.message)].join('')));
}

var G__36735 = cljs.core.next(seq__36290__$1);
var G__36736 = null;
var G__36737 = (0);
var G__36738 = (0);
seq__36290 = G__36735;
chunk__36291 = G__36736;
count__36292 = G__36737;
i__36293 = G__36738;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.cljs.devtools.client.browser.do_js_reload = (function shadow$cljs$devtools$client$browser$do_js_reload(msg,sources,complete_fn,failure_fn){
return shadow.cljs.devtools.client.env.do_js_reload.cljs$core$IFn$_invoke$arity$4(cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(msg,new cljs.core.Keyword(null,"log-missing-fn","log-missing-fn",732676765),(function (fn_sym){
return null;
}),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"log-call-async","log-call-async",183826192),(function (fn_sym){
return shadow.cljs.devtools.client.browser.devtools_msg(["call async ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(fn_sym)].join(''));
}),new cljs.core.Keyword(null,"log-call","log-call",412404391),(function (fn_sym){
return shadow.cljs.devtools.client.browser.devtools_msg(["call ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(fn_sym)].join(''));
})], 0)),(function (){
return shadow.cljs.devtools.client.browser.do_js_load(sources);
}),complete_fn,failure_fn);
});
/**
 * when (require '["some-str" :as x]) is done at the REPL we need to manually call the shadow.js.require for it
 * since the file only adds the shadow$provide. only need to do this for shadow-js.
 */
shadow.cljs.devtools.client.browser.do_js_requires = (function shadow$cljs$devtools$client$browser$do_js_requires(js_requires){
var seq__36312 = cljs.core.seq(js_requires);
var chunk__36313 = null;
var count__36314 = (0);
var i__36315 = (0);
while(true){
if((i__36315 < count__36314)){
var js_ns = chunk__36313.cljs$core$IIndexed$_nth$arity$2(null,i__36315);
var require_str_36740 = ["var ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns)," = shadow.js.require(\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns),"\");"].join('');
shadow.cljs.devtools.client.browser.script_eval(require_str_36740);


var G__36742 = seq__36312;
var G__36743 = chunk__36313;
var G__36744 = count__36314;
var G__36745 = (i__36315 + (1));
seq__36312 = G__36742;
chunk__36313 = G__36743;
count__36314 = G__36744;
i__36315 = G__36745;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__36312);
if(temp__5735__auto__){
var seq__36312__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__36312__$1)){
var c__4556__auto__ = cljs.core.chunk_first(seq__36312__$1);
var G__36746 = cljs.core.chunk_rest(seq__36312__$1);
var G__36747 = c__4556__auto__;
var G__36748 = cljs.core.count(c__4556__auto__);
var G__36749 = (0);
seq__36312 = G__36746;
chunk__36313 = G__36747;
count__36314 = G__36748;
i__36315 = G__36749;
continue;
} else {
var js_ns = cljs.core.first(seq__36312__$1);
var require_str_36751 = ["var ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns)," = shadow.js.require(\"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(js_ns),"\");"].join('');
shadow.cljs.devtools.client.browser.script_eval(require_str_36751);


var G__36752 = cljs.core.next(seq__36312__$1);
var G__36753 = null;
var G__36754 = (0);
var G__36755 = (0);
seq__36312 = G__36752;
chunk__36313 = G__36753;
count__36314 = G__36754;
i__36315 = G__36755;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.cljs.devtools.client.browser.handle_build_complete = (function shadow$cljs$devtools$client$browser$handle_build_complete(runtime,p__36321){
var map__36322 = p__36321;
var map__36322__$1 = (((((!((map__36322 == null))))?(((((map__36322.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36322.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36322):map__36322);
var msg = map__36322__$1;
var info = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36322__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var reload_info = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36322__$1,new cljs.core.Keyword(null,"reload-info","reload-info",1648088086));
var warnings = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.distinct.cljs$core$IFn$_invoke$arity$1((function (){var iter__4529__auto__ = (function shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__36324(s__36325){
return (new cljs.core.LazySeq(null,(function (){
var s__36325__$1 = s__36325;
while(true){
var temp__5735__auto__ = cljs.core.seq(s__36325__$1);
if(temp__5735__auto__){
var xs__6292__auto__ = temp__5735__auto__;
var map__36330 = cljs.core.first(xs__6292__auto__);
var map__36330__$1 = (((((!((map__36330 == null))))?(((((map__36330.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36330.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36330):map__36330);
var src = map__36330__$1;
var resource_name = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36330__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
var warnings = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36330__$1,new cljs.core.Keyword(null,"warnings","warnings",-735437651));
if(cljs.core.not(new cljs.core.Keyword(null,"from-jar","from-jar",1050932827).cljs$core$IFn$_invoke$arity$1(src))){
var iterys__4525__auto__ = ((function (s__36325__$1,map__36330,map__36330__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__36322,map__36322__$1,msg,info,reload_info){
return (function shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__36324_$_iter__36326(s__36327){
return (new cljs.core.LazySeq(null,((function (s__36325__$1,map__36330,map__36330__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__36322,map__36322__$1,msg,info,reload_info){
return (function (){
var s__36327__$1 = s__36327;
while(true){
var temp__5735__auto____$1 = cljs.core.seq(s__36327__$1);
if(temp__5735__auto____$1){
var s__36327__$2 = temp__5735__auto____$1;
if(cljs.core.chunked_seq_QMARK_(s__36327__$2)){
var c__4527__auto__ = cljs.core.chunk_first(s__36327__$2);
var size__4528__auto__ = cljs.core.count(c__4527__auto__);
var b__36329 = cljs.core.chunk_buffer(size__4528__auto__);
if((function (){var i__36328 = (0);
while(true){
if((i__36328 < size__4528__auto__)){
var warning = cljs.core._nth(c__4527__auto__,i__36328);
cljs.core.chunk_append(b__36329,cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(warning,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100),resource_name));

var G__36764 = (i__36328 + (1));
i__36328 = G__36764;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__36329),shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__36324_$_iter__36326(cljs.core.chunk_rest(s__36327__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__36329),null);
}
} else {
var warning = cljs.core.first(s__36327__$2);
return cljs.core.cons(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(warning,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100),resource_name),shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__36324_$_iter__36326(cljs.core.rest(s__36327__$2)));
}
} else {
return null;
}
break;
}
});})(s__36325__$1,map__36330,map__36330__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__36322,map__36322__$1,msg,info,reload_info))
,null,null));
});})(s__36325__$1,map__36330,map__36330__$1,src,resource_name,warnings,xs__6292__auto__,temp__5735__auto__,map__36322,map__36322__$1,msg,info,reload_info))
;
var fs__4526__auto__ = cljs.core.seq(iterys__4525__auto__(warnings));
if(fs__4526__auto__){
return cljs.core.concat.cljs$core$IFn$_invoke$arity$2(fs__4526__auto__,shadow$cljs$devtools$client$browser$handle_build_complete_$_iter__36324(cljs.core.rest(s__36325__$1)));
} else {
var G__36767 = cljs.core.rest(s__36325__$1);
s__36325__$1 = G__36767;
continue;
}
} else {
var G__36769 = cljs.core.rest(s__36325__$1);
s__36325__$1 = G__36769;
continue;
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4529__auto__(new cljs.core.Keyword(null,"sources","sources",-321166424).cljs$core$IFn$_invoke$arity$1(info));
})()));
var seq__36332_36773 = cljs.core.seq(warnings);
var chunk__36333_36774 = null;
var count__36334_36775 = (0);
var i__36335_36776 = (0);
while(true){
if((i__36335_36776 < count__36334_36775)){
var map__36340_36778 = chunk__36333_36774.cljs$core$IIndexed$_nth$arity$2(null,i__36335_36776);
var map__36340_36779__$1 = (((((!((map__36340_36778 == null))))?(((((map__36340_36778.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36340_36778.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36340_36778):map__36340_36778);
var w_36780 = map__36340_36779__$1;
var msg_36781__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36340_36779__$1,new cljs.core.Keyword(null,"msg","msg",-1386103444));
var line_36782 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36340_36779__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column_36783 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36340_36779__$1,new cljs.core.Keyword(null,"column","column",2078222095));
var resource_name_36784 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36340_36779__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
console.warn(["BUILD-WARNING in ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name_36784)," at [",cljs.core.str.cljs$core$IFn$_invoke$arity$1(line_36782),":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(column_36783),"]\n\t",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg_36781__$1)].join(''));


var G__36808 = seq__36332_36773;
var G__36809 = chunk__36333_36774;
var G__36810 = count__36334_36775;
var G__36811 = (i__36335_36776 + (1));
seq__36332_36773 = G__36808;
chunk__36333_36774 = G__36809;
count__36334_36775 = G__36810;
i__36335_36776 = G__36811;
continue;
} else {
var temp__5735__auto___36812 = cljs.core.seq(seq__36332_36773);
if(temp__5735__auto___36812){
var seq__36332_36813__$1 = temp__5735__auto___36812;
if(cljs.core.chunked_seq_QMARK_(seq__36332_36813__$1)){
var c__4556__auto___36814 = cljs.core.chunk_first(seq__36332_36813__$1);
var G__36816 = cljs.core.chunk_rest(seq__36332_36813__$1);
var G__36817 = c__4556__auto___36814;
var G__36818 = cljs.core.count(c__4556__auto___36814);
var G__36819 = (0);
seq__36332_36773 = G__36816;
chunk__36333_36774 = G__36817;
count__36334_36775 = G__36818;
i__36335_36776 = G__36819;
continue;
} else {
var map__36346_36820 = cljs.core.first(seq__36332_36813__$1);
var map__36346_36821__$1 = (((((!((map__36346_36820 == null))))?(((((map__36346_36820.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36346_36820.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36346_36820):map__36346_36820);
var w_36822 = map__36346_36821__$1;
var msg_36823__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36346_36821__$1,new cljs.core.Keyword(null,"msg","msg",-1386103444));
var line_36824 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36346_36821__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column_36825 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36346_36821__$1,new cljs.core.Keyword(null,"column","column",2078222095));
var resource_name_36826 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36346_36821__$1,new cljs.core.Keyword(null,"resource-name","resource-name",2001617100));
console.warn(["BUILD-WARNING in ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(resource_name_36826)," at [",cljs.core.str.cljs$core$IFn$_invoke$arity$1(line_36824),":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(column_36825),"]\n\t",cljs.core.str.cljs$core$IFn$_invoke$arity$1(msg_36823__$1)].join(''));


var G__36829 = cljs.core.next(seq__36332_36813__$1);
var G__36830 = null;
var G__36831 = (0);
var G__36832 = (0);
seq__36332_36773 = G__36829;
chunk__36333_36774 = G__36830;
count__36334_36775 = G__36831;
i__36335_36776 = G__36832;
continue;
}
} else {
}
}
break;
}

if((!(shadow.cljs.devtools.client.env.autoload))){
return shadow.cljs.devtools.client.hud.load_end_success();
} else {
if(((cljs.core.empty_QMARK_(warnings)) || (shadow.cljs.devtools.client.env.ignore_warnings))){
var sources_to_get = shadow.cljs.devtools.client.env.filter_reload_sources(info,reload_info);
if(cljs.core.not(cljs.core.seq(sources_to_get))){
return shadow.cljs.devtools.client.hud.load_end_success();
} else {
if(cljs.core.seq(cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(msg,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"reload-info","reload-info",1648088086),new cljs.core.Keyword(null,"after-load","after-load",-1278503285)], null)))){
} else {
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("reloading code but no :after-load hooks are configured!",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["https://shadow-cljs.github.io/docs/UsersGuide.html#_lifecycle_hooks"], 0));
}

return shadow.cljs.devtools.client.shared.load_sources(runtime,sources_to_get,(function (p1__36320_SHARP_){
return shadow.cljs.devtools.client.browser.do_js_reload(msg,p1__36320_SHARP_,shadow.cljs.devtools.client.hud.load_end_success,shadow.cljs.devtools.client.hud.load_failure);
}));
}
} else {
return null;
}
}
});
shadow.cljs.devtools.client.browser.page_load_uri = (cljs.core.truth_(goog.global.document)?goog.Uri.parse(document.location.href):null);
shadow.cljs.devtools.client.browser.match_paths = (function shadow$cljs$devtools$client$browser$match_paths(old,new$){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("file",shadow.cljs.devtools.client.browser.page_load_uri.getScheme())){
var rel_new = cljs.core.subs.cljs$core$IFn$_invoke$arity$2(new$,(1));
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(old,rel_new)) || (clojure.string.starts_with_QMARK_(old,[rel_new,"?"].join(''))))){
return rel_new;
} else {
return null;
}
} else {
var node_uri = goog.Uri.parse(old);
var node_uri_resolved = shadow.cljs.devtools.client.browser.page_load_uri.resolve(node_uri);
var node_abs = node_uri_resolved.getPath();
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$1(shadow.cljs.devtools.client.browser.page_load_uri.hasSameDomainAs(node_uri))) || (cljs.core.not(node_uri.hasDomain())))){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(node_abs,new$)){
return new$;
} else {
return false;
}
} else {
return false;
}
}
});
shadow.cljs.devtools.client.browser.handle_asset_update = (function shadow$cljs$devtools$client$browser$handle_asset_update(p__36354){
var map__36355 = p__36354;
var map__36355__$1 = (((((!((map__36355 == null))))?(((((map__36355.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36355.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36355):map__36355);
var msg = map__36355__$1;
var updates = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36355__$1,new cljs.core.Keyword(null,"updates","updates",2013983452));
var seq__36358 = cljs.core.seq(updates);
var chunk__36360 = null;
var count__36361 = (0);
var i__36362 = (0);
while(true){
if((i__36362 < count__36361)){
var path = chunk__36360.cljs$core$IIndexed$_nth$arity$2(null,i__36362);
if(clojure.string.ends_with_QMARK_(path,"css")){
var seq__36473_36844 = cljs.core.seq(cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(document.querySelectorAll("link[rel=\"stylesheet\"]")));
var chunk__36476_36845 = null;
var count__36477_36846 = (0);
var i__36478_36847 = (0);
while(true){
if((i__36478_36847 < count__36477_36846)){
var node_36848 = chunk__36476_36845.cljs$core$IIndexed$_nth$arity$2(null,i__36478_36847);
var path_match_36849 = shadow.cljs.devtools.client.browser.match_paths(node_36848.getAttribute("href"),path);
if(cljs.core.truth_(path_match_36849)){
var new_link_36850 = (function (){var G__36511 = node_36848.cloneNode(true);
G__36511.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_36849),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__36511;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_36849], 0));

goog.dom.insertSiblingAfter(new_link_36850,node_36848);

goog.dom.removeNode(node_36848);


var G__36853 = seq__36473_36844;
var G__36854 = chunk__36476_36845;
var G__36855 = count__36477_36846;
var G__36856 = (i__36478_36847 + (1));
seq__36473_36844 = G__36853;
chunk__36476_36845 = G__36854;
count__36477_36846 = G__36855;
i__36478_36847 = G__36856;
continue;
} else {
var G__36857 = seq__36473_36844;
var G__36858 = chunk__36476_36845;
var G__36859 = count__36477_36846;
var G__36860 = (i__36478_36847 + (1));
seq__36473_36844 = G__36857;
chunk__36476_36845 = G__36858;
count__36477_36846 = G__36859;
i__36478_36847 = G__36860;
continue;
}
} else {
var temp__5735__auto___36862 = cljs.core.seq(seq__36473_36844);
if(temp__5735__auto___36862){
var seq__36473_36863__$1 = temp__5735__auto___36862;
if(cljs.core.chunked_seq_QMARK_(seq__36473_36863__$1)){
var c__4556__auto___36864 = cljs.core.chunk_first(seq__36473_36863__$1);
var G__36865 = cljs.core.chunk_rest(seq__36473_36863__$1);
var G__36866 = c__4556__auto___36864;
var G__36867 = cljs.core.count(c__4556__auto___36864);
var G__36868 = (0);
seq__36473_36844 = G__36865;
chunk__36476_36845 = G__36866;
count__36477_36846 = G__36867;
i__36478_36847 = G__36868;
continue;
} else {
var node_36869 = cljs.core.first(seq__36473_36863__$1);
var path_match_36870 = shadow.cljs.devtools.client.browser.match_paths(node_36869.getAttribute("href"),path);
if(cljs.core.truth_(path_match_36870)){
var new_link_36871 = (function (){var G__36517 = node_36869.cloneNode(true);
G__36517.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_36870),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__36517;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_36870], 0));

goog.dom.insertSiblingAfter(new_link_36871,node_36869);

goog.dom.removeNode(node_36869);


var G__36872 = cljs.core.next(seq__36473_36863__$1);
var G__36873 = null;
var G__36874 = (0);
var G__36875 = (0);
seq__36473_36844 = G__36872;
chunk__36476_36845 = G__36873;
count__36477_36846 = G__36874;
i__36478_36847 = G__36875;
continue;
} else {
var G__36877 = cljs.core.next(seq__36473_36863__$1);
var G__36878 = null;
var G__36879 = (0);
var G__36880 = (0);
seq__36473_36844 = G__36877;
chunk__36476_36845 = G__36878;
count__36477_36846 = G__36879;
i__36478_36847 = G__36880;
continue;
}
}
} else {
}
}
break;
}


var G__36881 = seq__36358;
var G__36882 = chunk__36360;
var G__36883 = count__36361;
var G__36884 = (i__36362 + (1));
seq__36358 = G__36881;
chunk__36360 = G__36882;
count__36361 = G__36883;
i__36362 = G__36884;
continue;
} else {
var G__36885 = seq__36358;
var G__36886 = chunk__36360;
var G__36887 = count__36361;
var G__36888 = (i__36362 + (1));
seq__36358 = G__36885;
chunk__36360 = G__36886;
count__36361 = G__36887;
i__36362 = G__36888;
continue;
}
} else {
var temp__5735__auto__ = cljs.core.seq(seq__36358);
if(temp__5735__auto__){
var seq__36358__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__36358__$1)){
var c__4556__auto__ = cljs.core.chunk_first(seq__36358__$1);
var G__36891 = cljs.core.chunk_rest(seq__36358__$1);
var G__36892 = c__4556__auto__;
var G__36893 = cljs.core.count(c__4556__auto__);
var G__36894 = (0);
seq__36358 = G__36891;
chunk__36360 = G__36892;
count__36361 = G__36893;
i__36362 = G__36894;
continue;
} else {
var path = cljs.core.first(seq__36358__$1);
if(clojure.string.ends_with_QMARK_(path,"css")){
var seq__36522_36896 = cljs.core.seq(cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(document.querySelectorAll("link[rel=\"stylesheet\"]")));
var chunk__36527_36897 = null;
var count__36528_36898 = (0);
var i__36529_36899 = (0);
while(true){
if((i__36529_36899 < count__36528_36898)){
var node_36900 = chunk__36527_36897.cljs$core$IIndexed$_nth$arity$2(null,i__36529_36899);
var path_match_36901 = shadow.cljs.devtools.client.browser.match_paths(node_36900.getAttribute("href"),path);
if(cljs.core.truth_(path_match_36901)){
var new_link_36902 = (function (){var G__36551 = node_36900.cloneNode(true);
G__36551.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_36901),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__36551;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_36901], 0));

goog.dom.insertSiblingAfter(new_link_36902,node_36900);

goog.dom.removeNode(node_36900);


var G__36906 = seq__36522_36896;
var G__36907 = chunk__36527_36897;
var G__36908 = count__36528_36898;
var G__36909 = (i__36529_36899 + (1));
seq__36522_36896 = G__36906;
chunk__36527_36897 = G__36907;
count__36528_36898 = G__36908;
i__36529_36899 = G__36909;
continue;
} else {
var G__36910 = seq__36522_36896;
var G__36911 = chunk__36527_36897;
var G__36912 = count__36528_36898;
var G__36913 = (i__36529_36899 + (1));
seq__36522_36896 = G__36910;
chunk__36527_36897 = G__36911;
count__36528_36898 = G__36912;
i__36529_36899 = G__36913;
continue;
}
} else {
var temp__5735__auto___36914__$1 = cljs.core.seq(seq__36522_36896);
if(temp__5735__auto___36914__$1){
var seq__36522_36915__$1 = temp__5735__auto___36914__$1;
if(cljs.core.chunked_seq_QMARK_(seq__36522_36915__$1)){
var c__4556__auto___36916 = cljs.core.chunk_first(seq__36522_36915__$1);
var G__36917 = cljs.core.chunk_rest(seq__36522_36915__$1);
var G__36918 = c__4556__auto___36916;
var G__36919 = cljs.core.count(c__4556__auto___36916);
var G__36920 = (0);
seq__36522_36896 = G__36917;
chunk__36527_36897 = G__36918;
count__36528_36898 = G__36919;
i__36529_36899 = G__36920;
continue;
} else {
var node_36921 = cljs.core.first(seq__36522_36915__$1);
var path_match_36922 = shadow.cljs.devtools.client.browser.match_paths(node_36921.getAttribute("href"),path);
if(cljs.core.truth_(path_match_36922)){
var new_link_36923 = (function (){var G__36557 = node_36921.cloneNode(true);
G__36557.setAttribute("href",[cljs.core.str.cljs$core$IFn$_invoke$arity$1(path_match_36922),"?r=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.rand.cljs$core$IFn$_invoke$arity$0())].join(''));

return G__36557;
})();
shadow.cljs.devtools.client.browser.devtools_msg.cljs$core$IFn$_invoke$arity$variadic("load CSS",cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([path_match_36922], 0));

goog.dom.insertSiblingAfter(new_link_36923,node_36921);

goog.dom.removeNode(node_36921);


var G__36925 = cljs.core.next(seq__36522_36915__$1);
var G__36926 = null;
var G__36927 = (0);
var G__36928 = (0);
seq__36522_36896 = G__36925;
chunk__36527_36897 = G__36926;
count__36528_36898 = G__36927;
i__36529_36899 = G__36928;
continue;
} else {
var G__36931 = cljs.core.next(seq__36522_36915__$1);
var G__36932 = null;
var G__36933 = (0);
var G__36934 = (0);
seq__36522_36896 = G__36931;
chunk__36527_36897 = G__36932;
count__36528_36898 = G__36933;
i__36529_36899 = G__36934;
continue;
}
}
} else {
}
}
break;
}


var G__36935 = cljs.core.next(seq__36358__$1);
var G__36936 = null;
var G__36937 = (0);
var G__36938 = (0);
seq__36358 = G__36935;
chunk__36360 = G__36936;
count__36361 = G__36937;
i__36362 = G__36938;
continue;
} else {
var G__36939 = cljs.core.next(seq__36358__$1);
var G__36940 = null;
var G__36941 = (0);
var G__36942 = (0);
seq__36358 = G__36939;
chunk__36360 = G__36940;
count__36361 = G__36941;
i__36362 = G__36942;
continue;
}
}
} else {
return null;
}
}
break;
}
});
shadow.cljs.devtools.client.browser.global_eval = (function shadow$cljs$devtools$client$browser$global_eval(js){
if(cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2("undefined",typeof(module))){
return eval(js);
} else {
return (0,eval)(js);;
}
});
shadow.cljs.devtools.client.browser.repl_init = (function shadow$cljs$devtools$client$browser$repl_init(runtime,p__36561){
var map__36563 = p__36561;
var map__36563__$1 = (((((!((map__36563 == null))))?(((((map__36563.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36563.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36563):map__36563);
var repl_state = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36563__$1,new cljs.core.Keyword(null,"repl-state","repl-state",-1733780387));
return shadow.cljs.devtools.client.shared.load_sources(runtime,cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.remove.cljs$core$IFn$_invoke$arity$2(shadow.cljs.devtools.client.env.src_is_loaded_QMARK_,new cljs.core.Keyword(null,"repl-sources","repl-sources",723867535).cljs$core$IFn$_invoke$arity$1(repl_state))),(function (sources){
shadow.cljs.devtools.client.browser.do_js_load(sources);

return shadow.cljs.devtools.client.browser.devtools_msg("ready!");
}));
});
shadow.cljs.devtools.client.browser.client_info = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"host","host",-1558485167),(cljs.core.truth_(goog.global.document)?new cljs.core.Keyword(null,"browser","browser",828191719):new cljs.core.Keyword(null,"browser-worker","browser-worker",1638998282)),new cljs.core.Keyword(null,"user-agent","user-agent",1220426212),[(cljs.core.truth_(goog.userAgent.OPERA)?"Opera":(cljs.core.truth_(goog.userAgent.product.CHROME)?"Chrome":(cljs.core.truth_(goog.userAgent.IE)?"MSIE":(cljs.core.truth_(goog.userAgent.EDGE)?"Edge":(cljs.core.truth_(goog.userAgent.GECKO)?"Firefox":(cljs.core.truth_(goog.userAgent.SAFARI)?"Safari":(cljs.core.truth_(goog.userAgent.WEBKIT)?"Webkit":null)))))))," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(goog.userAgent.VERSION)," [",cljs.core.str.cljs$core$IFn$_invoke$arity$1(goog.userAgent.PLATFORM),"]"].join(''),new cljs.core.Keyword(null,"dom","dom",-1236537922),(!((goog.global.document == null)))], null);
if((typeof shadow !== 'undefined') && (typeof shadow.cljs !== 'undefined') && (typeof shadow.cljs.devtools !== 'undefined') && (typeof shadow.cljs.devtools.client !== 'undefined') && (typeof shadow.cljs.devtools.client.browser !== 'undefined') && (typeof shadow.cljs.devtools.client.browser.ws_was_welcome_ref !== 'undefined')){
} else {
shadow.cljs.devtools.client.browser.ws_was_welcome_ref = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(false);
}
if(((shadow.cljs.devtools.client.env.enabled) && ((shadow.cljs.devtools.client.env.worker_client_id > (0))))){
(shadow.cljs.devtools.client.shared.Runtime.prototype.shadow$remote$runtime$api$IEvalJS$ = cljs.core.PROTOCOL_SENTINEL);

(shadow.cljs.devtools.client.shared.Runtime.prototype.shadow$remote$runtime$api$IEvalJS$_js_eval$arity$2 = (function (this$,code){
var this$__$1 = this;
return shadow.cljs.devtools.client.browser.global_eval(code);
}));

(shadow.cljs.devtools.client.shared.Runtime.prototype.shadow$cljs$devtools$client$shared$IHostSpecific$ = cljs.core.PROTOCOL_SENTINEL);

(shadow.cljs.devtools.client.shared.Runtime.prototype.shadow$cljs$devtools$client$shared$IHostSpecific$do_invoke$arity$2 = (function (this$,p__36578){
var map__36579 = p__36578;
var map__36579__$1 = (((((!((map__36579 == null))))?(((((map__36579.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36579.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36579):map__36579);
var _ = map__36579__$1;
var js = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36579__$1,new cljs.core.Keyword(null,"js","js",1768080579));
var this$__$1 = this;
return shadow.cljs.devtools.client.browser.global_eval(js);
}));

(shadow.cljs.devtools.client.shared.Runtime.prototype.shadow$cljs$devtools$client$shared$IHostSpecific$do_repl_init$arity$4 = (function (runtime,p__36582,done,error){
var map__36583 = p__36582;
var map__36583__$1 = (((((!((map__36583 == null))))?(((((map__36583.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36583.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36583):map__36583);
var repl_sources = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36583__$1,new cljs.core.Keyword(null,"repl-sources","repl-sources",723867535));
var runtime__$1 = this;
return shadow.cljs.devtools.client.shared.load_sources(runtime__$1,cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.remove.cljs$core$IFn$_invoke$arity$2(shadow.cljs.devtools.client.env.src_is_loaded_QMARK_,repl_sources)),(function (sources){
shadow.cljs.devtools.client.browser.do_js_load(sources);

return (done.cljs$core$IFn$_invoke$arity$0 ? done.cljs$core$IFn$_invoke$arity$0() : done.call(null));
}));
}));

(shadow.cljs.devtools.client.shared.Runtime.prototype.shadow$cljs$devtools$client$shared$IHostSpecific$do_repl_require$arity$4 = (function (runtime,p__36585,done,error){
var map__36586 = p__36585;
var map__36586__$1 = (((((!((map__36586 == null))))?(((((map__36586.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36586.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36586):map__36586);
var msg = map__36586__$1;
var sources = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36586__$1,new cljs.core.Keyword(null,"sources","sources",-321166424));
var reload_namespaces = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36586__$1,new cljs.core.Keyword(null,"reload-namespaces","reload-namespaces",250210134));
var js_requires = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36586__$1,new cljs.core.Keyword(null,"js-requires","js-requires",-1311472051));
var runtime__$1 = this;
var sources_to_load = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.remove.cljs$core$IFn$_invoke$arity$2((function (p__36588){
var map__36589 = p__36588;
var map__36589__$1 = (((((!((map__36589 == null))))?(((((map__36589.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36589.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36589):map__36589);
var src = map__36589__$1;
var provides = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36589__$1,new cljs.core.Keyword(null,"provides","provides",-1634397992));
var and__4115__auto__ = shadow.cljs.devtools.client.env.src_is_loaded_QMARK_(src);
if(cljs.core.truth_(and__4115__auto__)){
return cljs.core.not(cljs.core.some(reload_namespaces,provides));
} else {
return and__4115__auto__;
}
}),sources));
if(cljs.core.not(cljs.core.seq(sources_to_load))){
var G__36591 = cljs.core.PersistentVector.EMPTY;
return (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(G__36591) : done.call(null,G__36591));
} else {
return shadow.remote.runtime.shared.call.cljs$core$IFn$_invoke$arity$3(runtime__$1,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"op","op",-1882987955),new cljs.core.Keyword(null,"cljs-load-sources","cljs-load-sources",-1458295962),new cljs.core.Keyword(null,"to","to",192099007),shadow.cljs.devtools.client.env.worker_client_id,new cljs.core.Keyword(null,"sources","sources",-321166424),cljs.core.into.cljs$core$IFn$_invoke$arity$3(cljs.core.PersistentVector.EMPTY,cljs.core.map.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"resource-id","resource-id",-1308422582)),sources_to_load)], null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"cljs-sources","cljs-sources",31121610),(function (p__36592){
var map__36593 = p__36592;
var map__36593__$1 = (((((!((map__36593 == null))))?(((((map__36593.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36593.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36593):map__36593);
var msg__$1 = map__36593__$1;
var sources__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36593__$1,new cljs.core.Keyword(null,"sources","sources",-321166424));
try{shadow.cljs.devtools.client.browser.do_js_load(sources__$1);

if(cljs.core.seq(js_requires)){
shadow.cljs.devtools.client.browser.do_js_requires(js_requires);
} else {
}

return (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(sources_to_load) : done.call(null,sources_to_load));
}catch (e36598){var ex = e36598;
return (error.cljs$core$IFn$_invoke$arity$1 ? error.cljs$core$IFn$_invoke$arity$1(ex) : error.call(null,ex));
}})], null));
}
}));

shadow.cljs.devtools.client.shared.add_plugin_BANG_(new cljs.core.Keyword("shadow.cljs.devtools.client.browser","client","shadow.cljs.devtools.client.browser/client",-1461019282),cljs.core.PersistentHashSet.EMPTY,(function (p__36613){
var map__36616 = p__36613;
var map__36616__$1 = (((((!((map__36616 == null))))?(((((map__36616.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36616.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36616):map__36616);
var env = map__36616__$1;
var runtime = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36616__$1,new cljs.core.Keyword(null,"runtime","runtime",-1331573996));
var svc = new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"runtime","runtime",-1331573996),runtime], null);
shadow.remote.runtime.api.add_extension(runtime,new cljs.core.Keyword("shadow.cljs.devtools.client.browser","client","shadow.cljs.devtools.client.browser/client",-1461019282),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"on-welcome","on-welcome",1895317125),(function (){
cljs.core.reset_BANG_(shadow.cljs.devtools.client.browser.ws_was_welcome_ref,true);

shadow.cljs.devtools.client.hud.connection_error_clear_BANG_();

shadow.cljs.devtools.client.env.patch_goog_BANG_();

return shadow.cljs.devtools.client.browser.devtools_msg(["#",cljs.core.str.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"client-id","client-id",-464622140).cljs$core$IFn$_invoke$arity$1(cljs.core.deref(new cljs.core.Keyword(null,"state-ref","state-ref",2127874952).cljs$core$IFn$_invoke$arity$1(runtime))))," ready!"].join(''));
}),new cljs.core.Keyword(null,"on-disconnect","on-disconnect",-809021814),(function (e){
if(cljs.core.truth_(cljs.core.deref(shadow.cljs.devtools.client.browser.ws_was_welcome_ref))){
shadow.cljs.devtools.client.hud.connection_error("The Websocket connection was closed!");

return cljs.core.reset_BANG_(shadow.cljs.devtools.client.browser.ws_was_welcome_ref,false);
} else {
return null;
}
}),new cljs.core.Keyword(null,"on-reconnect","on-reconnect",1239988702),(function (e){
return shadow.cljs.devtools.client.hud.connection_error("Reconnecting ...");
}),new cljs.core.Keyword(null,"ops","ops",1237330063),new cljs.core.PersistentArrayMap(null, 8, [new cljs.core.Keyword(null,"access-denied","access-denied",959449406),(function (msg){
cljs.core.reset_BANG_(shadow.cljs.devtools.client.browser.ws_was_welcome_ref,false);

return shadow.cljs.devtools.client.hud.connection_error(["Stale Output! Your loaded JS was not produced by the running shadow-cljs instance."," Is the watch for this build running?"].join(''));
}),new cljs.core.Keyword(null,"cljs-runtime-init","cljs-runtime-init",1305890232),(function (msg){
return shadow.cljs.devtools.client.browser.repl_init(runtime,msg);
}),new cljs.core.Keyword(null,"cljs-asset-update","cljs-asset-update",1224093028),(function (p__36673){
var map__36674 = p__36673;
var map__36674__$1 = (((((!((map__36674 == null))))?(((((map__36674.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36674.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36674):map__36674);
var msg = map__36674__$1;
var updates = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36674__$1,new cljs.core.Keyword(null,"updates","updates",2013983452));
return shadow.cljs.devtools.client.browser.handle_asset_update(msg);
}),new cljs.core.Keyword(null,"cljs-build-configure","cljs-build-configure",-2089891268),(function (msg){
return null;
}),new cljs.core.Keyword(null,"cljs-build-start","cljs-build-start",-725781241),(function (msg){
shadow.cljs.devtools.client.hud.hud_hide();

shadow.cljs.devtools.client.hud.load_start();

return shadow.cljs.devtools.client.env.run_custom_notify_BANG_(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(msg,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"build-start","build-start",-959649480)));
}),new cljs.core.Keyword(null,"cljs-build-complete","cljs-build-complete",273626153),(function (msg){
var msg__$1 = shadow.cljs.devtools.client.env.add_warnings_to_info(msg);
shadow.cljs.devtools.client.hud.hud_warnings(msg__$1);

shadow.cljs.devtools.client.browser.handle_build_complete(runtime,msg__$1);

return shadow.cljs.devtools.client.env.run_custom_notify_BANG_(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(msg__$1,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"build-complete","build-complete",-501868472)));
}),new cljs.core.Keyword(null,"cljs-build-failure","cljs-build-failure",1718154990),(function (msg){
shadow.cljs.devtools.client.hud.load_end();

shadow.cljs.devtools.client.hud.hud_error(msg);

return shadow.cljs.devtools.client.env.run_custom_notify_BANG_(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(msg,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"build-failure","build-failure",-2107487466)));
}),new cljs.core.Keyword("shadow.cljs.devtools.client.env","worker-notify","shadow.cljs.devtools.client.env/worker-notify",-1456820670),(function (p__36684){
var map__36685 = p__36684;
var map__36685__$1 = (((((!((map__36685 == null))))?(((((map__36685.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36685.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36685):map__36685);
var event_op = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36685__$1,new cljs.core.Keyword(null,"event-op","event-op",200358057));
var client_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36685__$1,new cljs.core.Keyword(null,"client-id","client-id",-464622140));
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"client-disconnect","client-disconnect",640227957),event_op)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(client_id,shadow.cljs.devtools.client.env.worker_client_id)))){
shadow.cljs.devtools.client.hud.connection_error_clear_BANG_();

return shadow.cljs.devtools.client.hud.connection_error("The watch for this build was stopped!");
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"client-connect","client-connect",-1113973888),event_op)){
shadow.cljs.devtools.client.hud.connection_error_clear_BANG_();

return shadow.cljs.devtools.client.hud.connection_error("The watch for this build was restarted. Reload required!");
} else {
return null;
}
}
})], null)], null));

return svc;
}),(function (p__36690){
var map__36691 = p__36690;
var map__36691__$1 = (((((!((map__36691 == null))))?(((((map__36691.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__36691.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36691):map__36691);
var svc = map__36691__$1;
var runtime = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36691__$1,new cljs.core.Keyword(null,"runtime","runtime",-1331573996));
return shadow.remote.runtime.api.del_extension(runtime,new cljs.core.Keyword("shadow.cljs.devtools.client.browser","client","shadow.cljs.devtools.client.browser/client",-1461019282));
}));

shadow.cljs.devtools.client.shared.init_runtime_BANG_(shadow.cljs.devtools.client.browser.client_info,shadow.cljs.devtools.client.websocket.start,shadow.cljs.devtools.client.websocket.send,shadow.cljs.devtools.client.websocket.stop);
} else {
}

//# sourceMappingURL=shadow.cljs.devtools.client.browser.js.map
