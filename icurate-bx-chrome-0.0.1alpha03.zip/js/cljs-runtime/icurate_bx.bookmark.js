goog.provide('icurate_bx.bookmark');
if((typeof icurate_bx !== 'undefined') && (typeof icurate_bx.bookmark !== 'undefined') && (typeof icurate_bx.bookmark.gql_ep !== 'undefined')){
} else {
icurate_bx.bookmark.gql_ep = "http://localhost:9999/graphql";
}
icurate_bx.bookmark.get_browser = (function icurate_bx$bookmark$get_browser(){
if(cljs.core.truth_((function (){var or__4126__auto__ = window.chrome;
if(cljs.core.truth_(or__4126__auto__)){
return or__4126__auto__;
} else {
var or__4126__auto____$1 = window.chrome.webstore;
if(cljs.core.truth_(or__4126__auto____$1)){
return or__4126__auto____$1;
} else {
return window.chrome.runtime;
}
}
})())){
return new cljs.core.Keyword(null,"chrome","chrome",1718738387);
} else {
if(cljs.core.truth_((function (){try{return (!((InstallTrigger == null)));
}catch (e26702){if((e26702 instanceof Error)){
var e = e26702;
return false;
} else {
if((e26702 instanceof TypeError)){
var e = e26702;
return false;
} else {
throw e26702;

}
}
}})())){
return new cljs.core.Keyword(null,"firefox","firefox",1283768880);
} else {
return new cljs.core.Keyword(null,"default","default",-1987822328);

}
}
});
if((typeof icurate_bx !== 'undefined') && (typeof icurate_bx.bookmark !== 'undefined') && (typeof icurate_bx.bookmark.get_browser_object !== 'undefined')){
} else {
icurate_bx.bookmark.get_browser_object = (function (){var method_table__4619__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__4620__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var method_cache__4621__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__4622__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__4623__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$3(cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),(function (){var fexpr__26733 = cljs.core.get_global_hierarchy;
return (fexpr__26733.cljs$core$IFn$_invoke$arity$0 ? fexpr__26733.cljs$core$IFn$_invoke$arity$0() : fexpr__26733.call(null));
})());
return (new cljs.core.MultiFn(cljs.core.symbol.cljs$core$IFn$_invoke$arity$2("icurate-bx.bookmark","get-browser-object"),icurate_bx.bookmark.get_browser,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__4623__auto__,method_table__4619__auto__,prefer_table__4620__auto__,method_cache__4621__auto__,cached_hierarchy__4622__auto__));
})();
}
icurate_bx.bookmark.get_browser_object.cljs$core$IMultiFn$_add_method$arity$3(null,new cljs.core.Keyword(null,"firefox","firefox",1283768880),(function (){
return browser_object;
}));
icurate_bx.bookmark.get_browser_object.cljs$core$IMultiFn$_add_method$arity$3(null,new cljs.core.Keyword(null,"chrome","chrome",1718738387),(function (){
return chrome;
}));
icurate_bx.bookmark.get_browser_object.cljs$core$IMultiFn$_add_method$arity$3(null,new cljs.core.Keyword(null,"default","default",-1987822328),(function (){
return browser_object;
}));
icurate_bx.bookmark.bm_attributes = (function icurate_bx$bookmark$bm_attributes(bm){
return new cljs.core.PersistentArrayMap(null, 7, [new cljs.core.Keyword(null,"id","id",-1388402092),bm.id,new cljs.core.Keyword(null,"parent-id","parent-id",-1400729131),bm.parentId,new cljs.core.Keyword(null,"date-added","date-added",-268860966),bm.dateAdded,new cljs.core.Keyword(null,"date-group-modified","date-group-modified",828401838),bm.dateGroupModified,new cljs.core.Keyword(null,"index","index",-1531685915),bm.index,new cljs.core.Keyword(null,"title","title",636505583),bm.title,new cljs.core.Keyword(null,"url","url",276297046),bm.url], null);
});

//# sourceMappingURL=icurate_bx.bookmark.js.map
