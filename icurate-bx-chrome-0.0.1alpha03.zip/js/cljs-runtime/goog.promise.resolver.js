goog.provide("goog.promise.Resolver");
goog.forwardDeclare("goog.Promise");
goog.promise.Resolver = function() {
};
goog.promise.Resolver.prototype.promise;
goog.promise.Resolver.prototype.resolve;
goog.promise.Resolver.prototype.reject;

//# sourceMappingURL=goog.promise.resolver.js.map
