function registerOmnibox$$module$icurate_bx$omnibox() {
  console.log("Registered Omnibox");
  browser.omnibox.setDefaultSuggestion({description:'Search your iCurate\n    (e.g. "hello world" | "massively parallel, distributed, containerized, kubernette controlled todo list")'});
  browser.omnibox.onInputChanged.addListener(function(text, addSuggestions) {
    console.log("Registering Omnibox Listener");
    /** @const */ var suggestions = [{content:"http://someurl.com", description:"suggestion 1"}, {content:"http://someurl.com", description:"suggestion 2"}];
    /** @const */ var p = new Promise(function(res, rej) {
      console.log("Resolving Promise");
      res(suggestions);
    });
    p.then(addSuggestions).catch(function() {
      return console.log("Omnibox Error!");
    });
  });
  browser.omnibox.onInputEntered.addListener(function(text, disposition) {
    var url = text;
    switch(disposition) {
      case "currentTab":
        browser.tabs.update({url:url});
        break;
      case "newForegroundTab":
        browser.tabs.create({url:url});
        break;
      case "newBackgroundTab":
        browser.tabs.create({url:url, active:false});
        break;
    }
  });
}
/** @const */ var module$icurate_bx$omnibox = {};
/** @const */ module$icurate_bx$omnibox.registerOmnibox = registerOmnibox$$module$icurate_bx$omnibox;

$CLJS.module$icurate_bx$omnibox=module$icurate_bx$omnibox;
//# sourceMappingURL=module$icurate_bx$omnibox.js.map
