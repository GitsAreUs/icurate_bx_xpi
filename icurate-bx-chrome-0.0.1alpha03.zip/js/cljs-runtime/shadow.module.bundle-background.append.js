
shadow.cljs.devtools.client.env.module_loaded('bundle-background');
;
SHADOW_ENV.setLoaded("icurate_bx.indexeddb.js");
SHADOW_ENV.setLoaded("module$icurate_bx$omnibox.js");
SHADOW_ENV.setLoaded("icurate_bx.background.js");
SHADOW_ENV.setLoaded("shadow.module.bundle-background.append.js");