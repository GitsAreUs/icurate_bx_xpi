goog.provide('icurate_bx.indexeddb');
icurate_bx.indexeddb.browser = icurate_bx.bookmark.get_browser_object.cljs$core$IFn$_invoke$arity$0();
icurate_bx.indexeddb.idb = window.indexedDB;
icurate_bx.indexeddb.db_version = cljs.core.atom.cljs$core$IFn$_invoke$arity$1((0));
icurate_bx.indexeddb.add_bookmark = (function icurate_bx$indexeddb$add_bookmark(bmk){
var req = icurate_bx.indexeddb.idb.open("icurate");
(req.onsuccess = (function (bmk_e){
var db = bmk_e.target.result;
var tx = db.transaction(["bms"],"readwrite");
var bms = tx.objectStore("bms");
var a_r = bms.add(bmk);
(a_r.onerror = (function (a_e){
return console.log("Failed to cache bookmakr: ",bmk.id,". Error: ",bmk_e.target.errorCode);
}));

return (a_r.onsuccess = (function (a_e){
return console.log("Bookmark: ",bmk.id," cached for curation. Key: ",a_e.target.result);
}));
}));

return (req.onerror = (function (bmk_e){
return console.log("Cannot cache bookmark: ",bmk.id,"Failed to open 'icurate' database. Error: ",bmk_e.target.errorCode);
}));
});
icurate_bx.indexeddb.initDB = (function icurate_bx$indexeddb$initDB(){

var del_req = icurate_bx.indexeddb.idb.deleteDatabase("icurate");
(del_req.onerror = (function (del_event){
return console.log("Failed to deleted 'icurate' database: ",del_event.target.errorCode);
}));

return (del_req.onsuccess = (function (del_event){
console.log("Creating 'icurate' database");

var db_req = icurate_bx.indexeddb.idb.open("icurate",cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(icurate_bx.indexeddb.db_version,cljs.core.inc));
(db_req.onupgradeneeded = (function (event){
console.log("Upgrading database icurate to version: ",cljs.core.deref(icurate_bx.indexeddb.db_version));

var db = event.target.result;
db.createObjectStore("bms",({"keyPath": "id"}));

return db.createObjectStore("c-bms",({"keyPath": "id"}));
}));

(db_req.onsuccess = (function (event){
console.log("icurate database created successuflly.");

var curate_bms = (function icurate_bx$indexeddb$initDB_$_curate_bms(bms_store,b_node){
var temp__5735__auto___26897 = b_node.children;
if(cljs.core.truth_(temp__5735__auto___26897)){
var children_26898 = temp__5735__auto___26897;
var seq__26781_26899 = cljs.core.seq(children_26898);
var chunk__26782_26900 = null;
var count__26783_26901 = (0);
var i__26784_26902 = (0);
while(true){
if((i__26784_26902 < count__26783_26901)){
var bm_26907 = chunk__26782_26900.cljs$core$IIndexed$_nth$arity$2(null,i__26784_26902);
icurate_bx$indexeddb$initDB_$_curate_bms(bms_store,bm_26907);


var G__26908 = seq__26781_26899;
var G__26909 = chunk__26782_26900;
var G__26910 = count__26783_26901;
var G__26911 = (i__26784_26902 + (1));
seq__26781_26899 = G__26908;
chunk__26782_26900 = G__26909;
count__26783_26901 = G__26910;
i__26784_26902 = G__26911;
continue;
} else {
var temp__5735__auto___26926__$1 = cljs.core.seq(seq__26781_26899);
if(temp__5735__auto___26926__$1){
var seq__26781_26932__$1 = temp__5735__auto___26926__$1;
if(cljs.core.chunked_seq_QMARK_(seq__26781_26932__$1)){
var c__4556__auto___26939 = cljs.core.chunk_first(seq__26781_26932__$1);
var G__26946 = cljs.core.chunk_rest(seq__26781_26932__$1);
var G__26947 = c__4556__auto___26939;
var G__26948 = cljs.core.count(c__4556__auto___26939);
var G__26949 = (0);
seq__26781_26899 = G__26946;
chunk__26782_26900 = G__26947;
count__26783_26901 = G__26948;
i__26784_26902 = G__26949;
continue;
} else {
var bm_26953 = cljs.core.first(seq__26781_26932__$1);
icurate_bx$indexeddb$initDB_$_curate_bms(bms_store,bm_26953);


var G__26954 = cljs.core.next(seq__26781_26932__$1);
var G__26955 = null;
var G__26956 = (0);
var G__26957 = (0);
seq__26781_26899 = G__26954;
chunk__26782_26900 = G__26955;
count__26783_26901 = G__26956;
i__26784_26902 = G__26957;
continue;
}
} else {
}
}
break;
}
} else {
}

var temp__5735__auto__ = b_node.url;
if(cljs.core.truth_(temp__5735__auto__)){
var url = temp__5735__auto__;
return bms_store.add(cljs.core.clj__GT_js(icurate_bx.bookmark.bm_attributes(b_node)));
} else {
return null;
}
});
var bookmark_url_nodes = (function (bms_tree_nodes){
var req = icurate_bx.indexeddb.idb.open("icurate");
(req.onsuccess = (function (event__$1){
console.log("Caching browser bookmarks");

var db = event.target.result;
var tx = db.transaction(["bms"],"readwrite");
var bms_os = tx.objectStore("bms");
var G__26802 = cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(cljs.core.first(cljs.core.array_seq.cljs$core$IFn$_invoke$arity$1(bms_tree_nodes)).children);
var vec__26803 = G__26802;
var seq__26804 = cljs.core.seq(vec__26803);
var first__26805 = cljs.core.first(seq__26804);
var seq__26804__$1 = cljs.core.next(seq__26804);
var bm_tree = first__26805;
var trees = seq__26804__$1;
var G__26802__$1 = G__26802;
while(true){
var vec__26810 = G__26802__$1;
var seq__26811 = cljs.core.seq(vec__26810);
var first__26812 = cljs.core.first(seq__26811);
var seq__26811__$1 = cljs.core.next(seq__26811);
var bm_tree__$1 = first__26812;
var trees__$1 = seq__26811__$1;
if(cljs.core.truth_(bm_tree__$1)){
curate_bms(bms_os,bm_tree__$1);

var G__26962 = trees__$1;
G__26802__$1 = G__26962;
continue;
} else {
return null;
}
break;
}
}));

return (req.onerror = (function (event__$1){
return console.log("Failed to open bms store for writing: ",event.target.errorCode);
}));
});
var pred__26816 = cljs.core._EQ_;
var expr__26817 = icurate_bx.bookmark.get_browser();
if(cljs.core.truth_((pred__26816.cljs$core$IFn$_invoke$arity$2 ? pred__26816.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"chrome","chrome",1718738387),expr__26817) : pred__26816.call(null,new cljs.core.Keyword(null,"chrome","chrome",1718738387),expr__26817)))){
var G__26820 = (function (bm_tree_nodes){
return bookmark_url_nodes(bm_tree_nodes);
});
return (icurate_bx.indexeddb.browser.bookmarks.getTree.cljs$core$IFn$_invoke$arity$1 ? icurate_bx.indexeddb.browser.bookmarks.getTree.cljs$core$IFn$_invoke$arity$1(G__26820) : icurate_bx.indexeddb.browser.bookmarks.getTree.call(null,G__26820));
} else {
if(cljs.core.truth_((pred__26816.cljs$core$IFn$_invoke$arity$2 ? pred__26816.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"firefox","firefox",1283768880),expr__26817) : pred__26816.call(null,new cljs.core.Keyword(null,"firefox","firefox",1283768880),expr__26817)))){
var bm_tree_nodes = (icurate_bx.indexeddb.browser.bookmarks.getTree.cljs$core$IFn$_invoke$arity$0 ? icurate_bx.indexeddb.browser.bookmarks.getTree.cljs$core$IFn$_invoke$arity$0() : icurate_bx.indexeddb.browser.bookmarks.getTree.call(null));
return bookmark_url_nodes(bm_tree_nodes);
} else {
if(cljs.core.truth_((pred__26816.cljs$core$IFn$_invoke$arity$2 ? pred__26816.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"default","default",-1987822328),expr__26817) : pred__26816.call(null,new cljs.core.Keyword(null,"default","default",-1987822328),expr__26817)))){
return consoloe.log("Browser not supported!!");
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(expr__26817)].join('')));
}
}
}
}));

return (db_req.onerror = (function (err_event){
return console.log("Failed to upgrade db to version: ",cljs.core.deref(icurate_bx.indexeddb.db_version),"Error code: ",err_event.target.errorCode);
}));
}));
});
icurate_bx.indexeddb.get_param = (function icurate_bx$indexeddb$get_param(url){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"with-credentials?","with-credentials?",-1773202222),true,new cljs.core.Keyword(null,"query-params","query-params",900640534),new cljs.core.PersistentArrayMap(null, 1, ["query",["mutation{curate_url(url: \"",cljs.core.str.cljs$core$IFn$_invoke$arity$1(url),"\")}"].join('')], null)], null);
});
icurate_bx.indexeddb.curator = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),(-1),new cljs.core.Keyword(null,"state","state",-1988618099),new cljs.core.Keyword(null,"STOPPED","STOPPED",-1920379804)], null));
icurate_bx.indexeddb.CURATION_FREQ_IN_MIN = (1);
icurate_bx.indexeddb.mark_curated = (function icurate_bx$indexeddb$mark_curated(resp,bmk_key){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((200),new cljs.core.Keyword(null,"status","status",-1997798413).cljs$core$IFn$_invoke$arity$1(resp))){
var req = icurate_bx.indexeddb.idb.open("icurate");
(req.onsuccess = (function (c_event){
var db = c_event.target.result;
var tx = db.transaction(["bms","c-bms"],"readwrite");
var bms = tx.objectStore("bms");
var c_bms = tx.objectStore("c-bms");
var bmk_res = bms.get(bmk_key);
(bmk_res.onsuccess = (function (bm_e){
var bmk = bm_e.target.result;
var a_r = c_bms.add(bmk);
return (a_r.onsuccess = (function (a_e){
return bms.delete(bmk_key);
}));
}));

return (bmk_res.onerror = (function (bm_e){
return console.log("Failed to get bookmark with key: ",bmk_key," from 'bms' store. Error: ",bm_e.target.errorCode);
}));
}));

return (req.onerror = (function (c_event){
return console.log("Failed to open 'icurate' database."," Could not mark bookmark key: ",bmk_key,"as curated"," Error code: ",c_event.target.errorCode);
}));
} else {
return console.log("Curation failed for bookmark key: ",bmk_key);
}
});
icurate_bx.indexeddb.curate = (function icurate_bx$indexeddb$curate(){

var req = icurate_bx.indexeddb.idb.open("icurate",cljs.core.deref(icurate_bx.indexeddb.db_version));
(req.onsuccess = (function (event){
try{var db = event.target.result;
var tx = db.transaction(["bms","c-bms"],"readonly");
var bms = tx.objectStore("bms");
var c_bms = tx.objectStore("c-bms");
var c_r = bms.openCursor();
console.log("Reading bookmarks...");

(c_r.onsuccess = (function (c_event){
var temp__5733__auto__ = c_event.target.result;
if(cljs.core.truth_(temp__5733__auto__)){
var cursor = temp__5733__auto__;
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"RUNNABLE","RUNNABLE",916393691),new cljs.core.Keyword(null,"state","state",-1988618099).cljs$core$IFn$_invoke$arity$1(cljs.core.deref(icurate_bx.indexeddb.curator)))){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.indexeddb.curator,cljs.core.assoc,new cljs.core.Keyword(null,"state","state",-1988618099),new cljs.core.Keyword(null,"RUNNING","RUNNING",-530451867));

var url_26981 = cursor.value.url;
var title_26982 = cursor.value.title;
var key_26983 = cursor.key;
cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(icurate_bx.bookmark.gql_ep,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([icurate_bx.indexeddb.get_param(url_26981)], 0)),(function (resp){
return icurate_bx.indexeddb.mark_curated(resp,key_26983);
}));

cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.indexeddb.curator,cljs.core.assoc,new cljs.core.Keyword(null,"state","state",-1988618099),new cljs.core.Keyword(null,"RUNNABLE","RUNNABLE",916393691));

return cursor.continue();
} else {
return null;
}
} else {
var id = setTimeout(icurate_bx.indexeddb.curate,((icurate_bx.indexeddb.CURATION_FREQ_IN_MIN * (60)) * (1000)));
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(icurate_bx.indexeddb.curator,cljs.core.assoc,new cljs.core.Keyword(null,"id","id",-1388402092),id);

return console.log("Rescheduled: ",cljs.core.prn_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.deref(icurate_bx.indexeddb.curator)], 0)));
}
}));

return (c_r.onerror = (function (c_event){
return console.log("Error fetching bookmark: ",c_event.target.errorCode);
}));
}catch (e26865){if((e26865 instanceof DOMException)){
var dexp = e26865;
var name = dexp.name;
var msg = dexp.message;
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(name,"NotFoundError")) && (clojure.string.starts_with_QMARK_(msg,"IDBDatabase.transaction:")))){
console.log("Object store 'bms' / 'c-bms' not found in 'icurate' database.");

console.log("Re-initializing 'icurate' database");

icurate_bx.indexeddb.initDB();

var id = setTimeout(icurate_bx.indexeddb.curate,((icurate_bx.indexeddb.CURATION_FREQ_IN_MIN * (60)) * (1000)));
cljs.core.reset_BANG_(icurate_bx.indexeddb.curator,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),id,new cljs.core.Keyword(null,"state","state",-1988618099),new cljs.core.Keyword(null,"RUNNABLE","RUNNABLE",916393691)], null));

return console.log("Rescheduled: ",cljs.core.prn_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.deref(icurate_bx.indexeddb.curator)], 0)));
} else {
return null;
}
} else {
throw e26865;

}
}}));

return (req.onerror = (function (event){
return console.log("Error opening icurate database: ",event.target.errorCode);
}));
});
icurate_bx.indexeddb.stop_curator = (function icurate_bx$indexeddb$stop_curator(){
clearTimeout(new cljs.core.Keyword(null,"id","id",-1388402092).cljs$core$IFn$_invoke$arity$1(cljs.core.deref(icurate_bx.indexeddb.curator)));

return cljs.core.reset_BANG_(icurate_bx.indexeddb.curator,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),(-1),new cljs.core.Keyword(null,"state","state",-1988618099),new cljs.core.Keyword(null,"STOPPED","STOPPED",-1920379804)], null));
});
icurate_bx.indexeddb.start_curator = (function icurate_bx$indexeddb$start_curator(){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"state","state",-1988618099).cljs$core$IFn$_invoke$arity$1(cljs.core.deref(icurate_bx.indexeddb.curator)),new cljs.core.Keyword(null,"STOPPED","STOPPED",-1920379804))){
var id = setTimeout(icurate_bx.indexeddb.curate,(10000));
return cljs.core.reset_BANG_(icurate_bx.indexeddb.curator,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),id,new cljs.core.Keyword(null,"state","state",-1988618099),new cljs.core.Keyword(null,"RUNNABLE","RUNNABLE",916393691)], null));
} else {
return null;
}
});

//# sourceMappingURL=icurate_bx.indexeddb.js.map
