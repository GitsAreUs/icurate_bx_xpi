goog.provide("goog.result.DependentResult");
goog.require("goog.result.Result");
goog.result.DependentResult = function() {
};
goog.result.DependentResult.prototype.getParentResults = function() {
};

//# sourceMappingURL=goog.result.dependentresult.js.map
